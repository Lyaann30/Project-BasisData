package com.example.arayalandbasdat;

import javafx.animation.*;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

class TotalPropertiYangDibeli{
    StringProperty nomor_Properti;
    StringProperty nama_Properti;
    DoubleProperty luas_Tanah_Properti;
    DoubleProperty harga_Tanah_Properti;
    DoubleProperty luas_Bangunan_Properti;
    DoubleProperty harga_Bangunan_Properti;
    DoubleProperty ppn_Properti;
    DoubleProperty harga_Total_Properti;
    StringProperty id_Transaksi;
    StringProperty status_Properti;


    public TotalPropertiYangDibeli() {
        this.nomor_Properti = new SimpleStringProperty();
        this.nama_Properti = new SimpleStringProperty();
        this.luas_Tanah_Properti = new SimpleDoubleProperty();
        this.harga_Tanah_Properti = new SimpleDoubleProperty();
        this.luas_Bangunan_Properti = new SimpleDoubleProperty();
        this.harga_Bangunan_Properti = new SimpleDoubleProperty();
        this.ppn_Properti = new SimpleDoubleProperty();
        this.harga_Total_Properti = new SimpleDoubleProperty();
        this.id_Transaksi = new SimpleStringProperty();
        this.status_Properti = new SimpleStringProperty();
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getNama_Properti() {
        return nama_Properti.get();
    }

    public StringProperty nama_PropertiProperty() {
        return nama_Properti;
    }

    public void setNama_Properti(String nama_Properti) {
        this.nama_Properti.set(nama_Properti);
    }

    public double getLuas_Tanah_Properti() {
        return luas_Tanah_Properti.get();
    }

    public DoubleProperty luas_Tanah_PropertiProperty() {
        return luas_Tanah_Properti;
    }

    public void setLuas_Tanah_Properti(double luas_Tanah_Properti) {
        this.luas_Tanah_Properti.set(luas_Tanah_Properti);
    }

    public double getHarga_Tanah_Properti() {
        return harga_Tanah_Properti.get();
    }

    public DoubleProperty harga_Tanah_PropertiProperty() {
        return harga_Tanah_Properti;
    }

    public void setHarga_Tanah_Properti(double harga_Tanah_Properti) {
        this.harga_Tanah_Properti.set(harga_Tanah_Properti);
    }

    public double getLuas_Bangunan_Properti() {
        return luas_Bangunan_Properti.get();
    }

    public DoubleProperty luas_Bangunan_PropertiProperty() {
        return luas_Bangunan_Properti;
    }

    public void setLuas_Bangunan_Properti(double luas_Bangunan_Properti) {
        this.luas_Bangunan_Properti.set(luas_Bangunan_Properti);
    }

    public double getHarga_Bangunan_Properti() {
        return harga_Bangunan_Properti.get();
    }

    public DoubleProperty harga_Bangunan_PropertiProperty() {
        return harga_Bangunan_Properti;
    }

    public void setHarga_Bangunan_Properti(double harga_Bangunan_Properti) {
        this.harga_Bangunan_Properti.set(harga_Bangunan_Properti);
    }

    public double getPpn_Properti() {
        return ppn_Properti.get();
    }

    public DoubleProperty ppn_PropertiProperty() {
        return ppn_Properti;
    }

    public void setPpn_Properti(double ppn_Properti) {
        this.ppn_Properti.set(ppn_Properti);
    }

    public double getHarga_Total_Properti() {
        return harga_Total_Properti.get();
    }

    public DoubleProperty harga_Total_PropertiProperty() {
        return harga_Total_Properti;
    }

    public void setHarga_Total_Properti(double harga_Total_Properti) {
        this.harga_Total_Properti.set(harga_Total_Properti);
    }

    public String getId_Transaksi() {
        return id_Transaksi.get();
    }

    public StringProperty id_TransaksiProperty() {
        return id_Transaksi;
    }

    public void setId_Transaksi(String id_Transaksi) {
        this.id_Transaksi.set(id_Transaksi);
    }

    public String getStatus_Properti() {
        return status_Properti.get();
    }

    public StringProperty status_PropertiProperty() {
        return status_Properti;
    }

    public void setStatus_Properti(String status_Properti) {
        this.status_Properti.set(status_Properti);
    }
}



class AllFasilitasCustomer {
    StringProperty nomor_Properti;
    StringProperty nama_Properti;
    StringProperty hari_Operasional;
    StringProperty jam_Operasional;

    public AllFasilitasCustomer() {
        this.nomor_Properti = new SimpleStringProperty();
        this.nama_Properti = new SimpleStringProperty();
        this.hari_Operasional = new SimpleStringProperty();
        this.jam_Operasional = new SimpleStringProperty();
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getNama_Properti() {
        return nama_Properti.get();
    }

    public StringProperty nama_PropertiProperty() {
        return nama_Properti;
    }

    public void setNama_Properti(String nama_Properti) {
        this.nama_Properti.set(nama_Properti);
    }

    public String getHari_Operasional() {
        return hari_Operasional.get();
    }

    public StringProperty hari_OperasionalProperty() {
        return hari_Operasional;
    }

    public void setHari_Operasional(String hari_Operasional) {
        this.hari_Operasional.set(hari_Operasional);
    }

    public String getJam_Operasional() {
        return jam_Operasional.get();
    }

    public StringProperty jam_OperasionalProperty() {
        return jam_Operasional;
    }

    public void setJam_Operasional(String jam_Operasional) {
        this.jam_Operasional.set(jam_Operasional);
    }
}

class AllKomunitasCustomer{
    StringProperty nomor_Properti;
    StringProperty nama_Komunitas;
    StringProperty agenda_Komunitas;

    public AllKomunitasCustomer() {
        this.nomor_Properti = new SimpleStringProperty();
        this.nama_Komunitas = new SimpleStringProperty();
        this.agenda_Komunitas = new SimpleStringProperty();
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getNama_Komunitas() {
        return nama_Komunitas.get();
    }

    public StringProperty nama_KomunitasProperty() {
        return nama_Komunitas;
    }

    public void setNama_Komunitas(String nama_Komunitas) {
        this.nama_Komunitas.set(nama_Komunitas);
    }

    public String getAgenda_Komunitas() {
        return agenda_Komunitas.get();
    }

    public StringProperty agenda_KomunitasProperty() {
        return agenda_Komunitas;
    }

    public void setAgenda_Komunitas(String agenda_Komunitas) {
        this.agenda_Komunitas.set(agenda_Komunitas);
    }
}

class AllLayananKebersihanCustomer{
    StringProperty nomor_Properti;
    StringProperty id_Pengangkutan;
    StringProperty hari_Operasional;
    StringProperty jam_Operasional;
    StringProperty Jenis_Truk;

    public AllLayananKebersihanCustomer() {
        this.nomor_Properti = new SimpleStringProperty();
        this.id_Pengangkutan = new SimpleStringProperty();
        this.hari_Operasional = new SimpleStringProperty();
        this.jam_Operasional = new SimpleStringProperty();
        this.Jenis_Truk = new SimpleStringProperty();
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getId_Pengangkutan() {
        return id_Pengangkutan.get();
    }

    public StringProperty id_PengangkutanProperty() {
        return id_Pengangkutan;
    }

    public void setId_Pengangkutan(String id_Pengangkutan) {
        this.id_Pengangkutan.set(id_Pengangkutan);
    }

    public String getHari_Operasional() {
        return hari_Operasional.get();
    }

    public StringProperty hari_OperasionalProperty() {
        return hari_Operasional;
    }

    public void setHari_Operasional(String hari_Operasional) {
        this.hari_Operasional.set(hari_Operasional);
    }

    public String getJam_Operasional() {
        return jam_Operasional.get();
    }

    public StringProperty jam_OperasionalProperty() {
        return jam_Operasional;
    }

    public void setJam_Operasional(String jam_Operasional) {
        this.jam_Operasional.set(jam_Operasional);
    }

    public String getJenis_Truk() {
        return Jenis_Truk.get();
    }

    public StringProperty jenis_TrukProperty() {
        return Jenis_Truk;
    }

    public void setJenis_Truk(String jenis_Truk) {
        this.Jenis_Truk.set(jenis_Truk);
    }
}

class RekapCustomer{
    StringProperty totalPropertiDibeli;
    StringProperty totalFasilitasDiakses;
    StringProperty totalKomunitasDIikuti;
    StringProperty totalKebersihanLangganan;

    public RekapCustomer() {
        this.totalPropertiDibeli = new SimpleStringProperty();
        this.totalFasilitasDiakses = new SimpleStringProperty();
        this.totalKomunitasDIikuti = new SimpleStringProperty();
        this.totalKebersihanLangganan = new SimpleStringProperty();
    }

    public String getTotalPropertiDibeli() {
        return totalPropertiDibeli.get();
    }

    public StringProperty totalPropertiDibeliProperty() {
        return totalPropertiDibeli;
    }

    public void setTotalPropertiDibeli(String totalPropertiDibeli) {
        this.totalPropertiDibeli.set(totalPropertiDibeli);
    }

    public String getTotalFasilitasDiakses() {
        return totalFasilitasDiakses.get();
    }

    public StringProperty totalFasilitasDiaksesProperty() {
        return totalFasilitasDiakses;
    }

    public void setTotalFasilitasDiakses(String totalFasilitasDiakses) {
        this.totalFasilitasDiakses.set(totalFasilitasDiakses);
    }

    public String getTotalKomunitasDIikuti() {
        return totalKomunitasDIikuti.get();
    }

    public StringProperty totalKomunitasDIikutiProperty() {
        return totalKomunitasDIikuti;
    }

    public void setTotalKomunitasDIikuti(String totalKomunitasDIikuti) {
        this.totalKomunitasDIikuti.set(totalKomunitasDIikuti);
    }

    public String getTotalKebersihanLangganan() {
        return totalKebersihanLangganan.get();
    }

    public StringProperty totalKebersihanLanggananProperty() {
        return totalKebersihanLangganan;
    }

    public void setTotalKebersihanLangganan(String totalKebersihanLangganan) {
        this.totalKebersihanLangganan.set(totalKebersihanLangganan);
    }
}

public class CustomerOwnership extends Application {
    Rectangle navigasi;
    HBox all;
    ScrollPane scrollPane;
    ImageView logo;
    ImageView logout;
    ImageView iconBeliProperti;
    ImageView iconAksesFasilitas;
    ImageView iconJoinKomunitas;
    ImageView iconBerlanggananCS;
    ImageView iconOwnership;
    GridPane navGridPane;
    StackPane contentkanan;
    StackPane navigasikiri;
    Text dashBoardtxt;
    Line garisdashBoardtxt;
    Circle lingkaranActive;
    TextField username123;
    ImageView excel1;

    Text texttotalDIBELI;
    TextField totalPropertiDIBELI;
    Text texttotalAKSESFASILITAS;
    TextField totalAKSESFASILITAS;
    Text texttotalGABUNGKOMUNITAS;
    TextField totalGABUNGKOMUNITAS;
    Text texttotalKEBERSIHAN;
    TextField totalKEBERSIHAN;
    Button jual;
    Button berhenti1;
    Button keluar;
    Button berhenti2;


    private TableView<TotalPropertiYangDibeli> tableTotalPropertiYangDibeli;
    private TableView<AllFasilitasCustomer> tableAllFasilitasCustomer;
    private TableView<AllKomunitasCustomer> tableAllKomunitasCustomer;
    private TableView<AllLayananKebersihanCustomer> tableAllLayananKebersihanCustomer;
    private TableView<RekapCustomer> tableRekapCustomer;
    private static int fileCounter = 0;

    private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/xe"; // Sesuaikan dengan URL database Anda
    private static final String DB_USER = "SYSTEM"; // Ganti dengan username database Anda
    private static final String DB_PASSWORD = "SYSTEM";



    @Override
    public void start(Stage stage) throws Exception {
        //navigasi kiri

        logo = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/logo.png")));
        logo.setFitWidth(200);
        logo.setFitHeight(200);
        logo.setTranslateX(-10);
        logo.setTranslateY(-2420);

        logo.setBlendMode(BlendMode.ADD);


        Timeline timelineLogo = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(logo.opacityProperty(), 0.2)),
                new KeyFrame(Duration.seconds(2), new KeyValue(logo.opacityProperty(), 1.0)),
                new KeyFrame(Duration.seconds(4), new KeyValue(logo.opacityProperty(), 0.2))
        );
        timelineLogo.setCycleCount(Animation.INDEFINITE);
        timelineLogo.play();

        Glow glow = new Glow(0.8);
        logo.setEffect(glow);

        iconBeliProperti = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Beli_Properti.png")));
        iconBeliProperti.setFitWidth(90);
        iconBeliProperti.setFitHeight(90);
        iconBeliProperti.setOnMouseEntered(event -> iconBeliProperti.setCursor(Cursor.HAND));
        iconBeliProperti.setOnMouseExited(event -> iconBeliProperti.setCursor(Cursor.DEFAULT));

        iconAksesFasilitas = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Akses_Fasilitas.png")));
        iconAksesFasilitas.setFitWidth(100);
        iconAksesFasilitas.setFitHeight(100);
        iconAksesFasilitas.setOnMouseEntered(event -> iconAksesFasilitas.setCursor(Cursor.HAND));
        iconAksesFasilitas.setOnMouseExited(event -> iconAksesFasilitas.setCursor(Cursor.DEFAULT));

        iconJoinKomunitas = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Bergabung_Komunitas.png")));
        iconJoinKomunitas.setFitWidth(100);
        iconJoinKomunitas.setFitHeight(100);
        iconJoinKomunitas.setOnMouseEntered(event -> iconJoinKomunitas.setCursor(Cursor.HAND));
        iconJoinKomunitas.setOnMouseExited(event -> iconJoinKomunitas.setCursor(Cursor.DEFAULT));

        iconOwnership = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Properti_Saya.png")));
        iconOwnership.setFitWidth(100);
        iconOwnership.setFitHeight(100);
        iconOwnership.setOnMouseEntered(event -> iconOwnership.setCursor(Cursor.HAND));
        iconOwnership.setOnMouseExited(event -> iconOwnership.setCursor(Cursor.DEFAULT));

        iconBerlanggananCS = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Berlangganan_Kebersihan.png")));
        iconBerlanggananCS.setFitWidth(100);
        iconBerlanggananCS.setFitHeight(100);
        iconBerlanggananCS.setOnMouseEntered(event -> iconBerlanggananCS.setCursor(Cursor.HAND));
        iconBerlanggananCS.setOnMouseExited(event -> iconBerlanggananCS.setCursor(Cursor.DEFAULT));

        logout = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/logout.png")));
        logout.setFitWidth(100);
        logout.setFitHeight(100);
        logout.setTranslateY(2450);
        logout.setOnMouseEntered(event -> logout.setCursor(Cursor.HAND));
        logout.setOnMouseExited(event -> logout.setCursor(Cursor.DEFAULT));

        navGridPane = new GridPane();
        navGridPane.setVgap(40);
        navGridPane.add(iconBeliProperti,0,1);
        navGridPane.add(iconAksesFasilitas,0,2);
        navGridPane.add(iconJoinKomunitas,0,3);
        navGridPane.add(iconOwnership,0,5);
        navGridPane.add(iconBerlanggananCS,0,4);
        navGridPane.setAlignment(Pos.CENTER);
        navGridPane.setTranslateX(0);
        navGridPane.setTranslateY(-2020);

        navigasi = new Rectangle(250,5000, Color.web("#316d18"));


        //content kanan

        dashBoardtxt = new Text("Properti Saya");
        dashBoardtxt.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 40px; "
                + "-fx-fill: #545454; -fx-font-weight: bold");
        dashBoardtxt.setTranslateX(-480);
        dashBoardtxt.setTranslateY(-2430);

        garisdashBoardtxt = new Line();
        garisdashBoardtxt.setStartX(270);  // Koordinat awal garis
        garisdashBoardtxt.setEndX(1535);    // Koordinat akhir garis (sesuaikan panjang sesuai kebutuhan)
        garisdashBoardtxt.setTranslateY(-2380);  // Sesuaikan posisi vertikal
        garisdashBoardtxt.setStroke(Color.web("#a6a6a6"));  // Warna garis
        garisdashBoardtxt.setStrokeWidth(5);  // Ketebalan garis
        garisdashBoardtxt.setTranslateX(0);

        lingkaranActive = new Circle(10,Color.LIMEGREEN);
        lingkaranActive.setTranslateY(-2410);
        lingkaranActive.setTranslateX(450);


        username123 = new TextField(username);
        username123.setStyle("-fx-font-family: 'Montserrat'; -fx-background-color: #a6a6a6;"
                + "-fx-font-size: 17px;-fx-font-weight: bold; "
                + "-fx-prompt-text-fill: white; -fx-text-fill: white;"
                + "-fx-background-radius: 30; "
                + "-fx-border-radius: 30;"
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; ");
        username123.setMaxWidth(200);
        username123.setTranslateX(530);
        username123.setTranslateY(-2410);
        username123.setEditable(false);
        username123.setAlignment(Pos.CENTER);


        //table1

        tableTotalPropertiYangDibeli = new TableView<>();

        TableColumn<TotalPropertiYangDibeli, String> nomorProperti1 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti1.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti1.setPrefWidth(120);

        TableColumn<TotalPropertiYangDibeli, String> namaProperti1 = new TableColumn<>("NAMA PROPERTI");
        namaProperti1.setCellValueFactory(cellData -> cellData.getValue().nama_PropertiProperty());
        namaProperti1.setPrefWidth(120);

        TableColumn<TotalPropertiYangDibeli, Number> luasTanahProperti1 = new TableColumn<>("LUAS TANAH");
        luasTanahProperti1.setCellValueFactory(cellData -> cellData.getValue().luas_Tanah_PropertiProperty());
        luasTanahProperti1.setPrefWidth(120);

        TableColumn<TotalPropertiYangDibeli, Number> hargaTanahproperti1 = new TableColumn<>("HARGA TANAH");
        hargaTanahproperti1.setCellValueFactory(cellData -> cellData.getValue().harga_Tanah_PropertiProperty());
        hargaTanahproperti1.setPrefWidth(150);
        hargaTanahproperti1.setCellFactory(tc -> new TableCell<TotalPropertiYangDibeli, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDibeli, Number> luasBangunanProperti1 = new TableColumn<>("LUAS BANGUNAN");
        luasBangunanProperti1.setCellValueFactory(cellData -> cellData.getValue().luas_Bangunan_PropertiProperty());
        luasBangunanProperti1.setPrefWidth(120);

        TableColumn<TotalPropertiYangDibeli, Number> hargaBangunanProperti1 = new TableColumn<>("HARGA BANGUNAN");
        hargaBangunanProperti1.setCellValueFactory(cellData -> cellData.getValue().harga_Bangunan_PropertiProperty());
        hargaBangunanProperti1.setPrefWidth(150);
        hargaBangunanProperti1.setCellFactory(tc -> new TableCell<TotalPropertiYangDibeli, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDibeli, Number> ppnProperti1 = new TableColumn<>("PPN 10%");
        ppnProperti1.setCellValueFactory(cellData -> cellData.getValue().ppn_PropertiProperty());
        ppnProperti1.setPrefWidth(150);
        ppnProperti1.setCellFactory(tc -> new TableCell<TotalPropertiYangDibeli, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDibeli, Number> hargaTotalProperti1 = new TableColumn<>("HARGA TOTAL");
        hargaTotalProperti1.setCellValueFactory(cellData -> cellData.getValue().harga_Total_PropertiProperty());
        hargaTotalProperti1.setPrefWidth(150);
        hargaTotalProperti1.setCellFactory(tc -> new TableCell<TotalPropertiYangDibeli, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDibeli, String> idTransaksi1 = new TableColumn<>("ID TRANSAKSI");
        idTransaksi1.setCellValueFactory(cellData -> cellData.getValue().id_TransaksiProperty());
        idTransaksi1.setPrefWidth(120);

        TableColumn<TotalPropertiYangDibeli, String> status_Properti1 = new TableColumn<>("STATUS");
        status_Properti1.setCellValueFactory(cellData -> cellData.getValue().status_PropertiProperty());
        status_Properti1.setPrefWidth(150);

        tableTotalPropertiYangDibeli.getColumns().addAll(
                nomorProperti1,
                namaProperti1,
                luasTanahProperti1,
                hargaTanahproperti1,
                luasBangunanProperti1,
                hargaBangunanProperti1,
                ppnProperti1,
                hargaTotalProperti1,
                idTransaksi1,
                status_Properti1
        );
        tableTotalPropertiYangDibeli.setTranslateY(-2100);
        tableTotalPropertiYangDibeli.setMaxWidth(1200);
        tableTotalPropertiYangDibeli.setMaxHeight(420);
        tableTotalPropertiYangDibeli.setEditable(false);



        jual = new Button("JUAL");
        jual.setStyle("-fx-background-color: #ff2121; -fx-font-size: 17px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        jual.setTranslateX(0);
        jual.setTranslateY(-1860);
        jual.setMaxWidth(150);

        Rectangle cardDownlaod = new Rectangle(300,300,Color.web("#DDDDDD"));
        cardDownlaod.setArcWidth(50); // Set lebar sudut
        cardDownlaod.setArcHeight(50); // Set tinggi sudut
        cardDownlaod.setTranslateX(410);
        cardDownlaod.setTranslateY(900);


        Text downloadExcel = new Text("Download Laporan Excel" +
                "\nDisini ⬇");
        downloadExcel.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        downloadExcel.setFill(Color.GREEN);
        downloadExcel.setTextAlignment(TextAlignment.CENTER);
        downloadExcel.setTranslateX(410);
        downloadExcel.setTranslateY(800);

        excel1 = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/EXCEL1.png")));
        excel1.setFitWidth(170);
        excel1.setFitHeight(170);
        excel1.setTranslateX(410);
        excel1.setTranslateY(950);

        texttotalDIBELI = new Text("TOTAL PROPERTI : " +
                "\n (YANG DIBELI)");
        texttotalDIBELI.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalDIBELI.setTranslateX(-500);
        texttotalDIBELI.setTranslateY(-1700);

        totalPropertiDIBELI = new TextField("0");
        totalPropertiDIBELI.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalPropertiDIBELI.setTranslateX(-300);
        totalPropertiDIBELI.setTranslateY(-1700);
        totalPropertiDIBELI.setMaxWidth(100);
        totalPropertiDIBELI.setEditable(false);
        totalPropertiDIBELI.setAlignment(Pos.CENTER);
        totalPropertiDIBELI.textProperty().bind(Bindings.size(tableTotalPropertiYangDibeli.getItems()).asString());


        //table2
        tableAllFasilitasCustomer = new TableView<>();

        TableColumn<AllFasilitasCustomer, String> nomorProperti2 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti2.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti2.setPrefWidth(300);

        TableColumn<AllFasilitasCustomer, String> namaProperti2 = new TableColumn<>("NAMA PROPERTI");
        namaProperti2.setCellValueFactory(cellData -> cellData.getValue().nama_PropertiProperty());
        namaProperti2.setPrefWidth(300);

        TableColumn<AllFasilitasCustomer, String> hariOperasional2 = new TableColumn<>("HARI OPERASIONAL");
        hariOperasional2.setCellValueFactory(cellData -> cellData.getValue().hari_OperasionalProperty());
        hariOperasional2.setPrefWidth(300);

        TableColumn<AllFasilitasCustomer, String> jamOperasional2 = new TableColumn<>("JAM OPERASIONAL");
        jamOperasional2.setCellValueFactory(cellData -> cellData.getValue().jam_OperasionalProperty());
        jamOperasional2.setPrefWidth(300);

        tableAllFasilitasCustomer.getColumns().addAll(
                nomorProperti2,
                namaProperti2,
                hariOperasional2,
                jamOperasional2
        );
        tableAllFasilitasCustomer.setTranslateY(-1300);
        tableAllFasilitasCustomer.setMaxWidth(1200);
        tableAllFasilitasCustomer.setMaxHeight(420);
        tableAllFasilitasCustomer.setEditable(false);


        berhenti1 = new Button("BERHENTI");
        berhenti1.setStyle("-fx-background-color: #ff2121; -fx-font-size: 17px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        berhenti1.setTranslateX(0);
        berhenti1.setTranslateY(-1060);
        berhenti1.setMaxWidth(150);


        texttotalAKSESFASILITAS = new Text("TOTAL FASILITAS : " +
                "\n (YANG DIAKSES)");
        texttotalAKSESFASILITAS.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalAKSESFASILITAS.setTranslateX(-500);
        texttotalAKSESFASILITAS.setTranslateY(-900);

        totalAKSESFASILITAS = new TextField("0");
        totalAKSESFASILITAS.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalAKSESFASILITAS.setTranslateX(-300);
        totalAKSESFASILITAS.setTranslateY(-900);
        totalAKSESFASILITAS.setMaxWidth(100);
        totalAKSESFASILITAS.setEditable(false);
        totalAKSESFASILITAS.setAlignment(Pos.CENTER);
        totalAKSESFASILITAS.textProperty().bind(Bindings.size(tableAllFasilitasCustomer.getItems()).asString());


        //table3
        tableAllKomunitasCustomer = new TableView<>();

        TableColumn<AllKomunitasCustomer, String> nomorProperti3 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti3.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti3.setPrefWidth(400);

        TableColumn<AllKomunitasCustomer, String> namaKomunitas3 = new TableColumn<>("NAMA KOMUNITAS");
        namaKomunitas3.setCellValueFactory(cellData -> cellData.getValue().nama_KomunitasProperty());
        namaKomunitas3.setPrefWidth(400);

        TableColumn<AllKomunitasCustomer, String> agenda3 = new TableColumn<>("AGENDA");
        agenda3.setCellValueFactory(cellData -> cellData.getValue().agenda_KomunitasProperty());
        agenda3.setPrefWidth(400);

        tableAllKomunitasCustomer.getColumns().addAll(
                nomorProperti3,
                namaKomunitas3,
                agenda3
        );

        tableAllKomunitasCustomer.setTranslateY(-500);
        tableAllKomunitasCustomer.setMaxWidth(1200);
        tableAllKomunitasCustomer.setMaxHeight(420);
        tableAllKomunitasCustomer.setEditable(false);


        keluar = new Button("KELUAR");
        keluar.setStyle("-fx-background-color: #ff2121; -fx-font-size: 17px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        keluar.setTranslateX(0);
        keluar.setTranslateY(-260);
        keluar.setMaxWidth(150);


        texttotalGABUNGKOMUNITAS = new Text("TOTAL KOMUNITAS : " +
                "\n (YANG DIIKUTI)");
        texttotalGABUNGKOMUNITAS.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalGABUNGKOMUNITAS.setTranslateX(-500);
        texttotalGABUNGKOMUNITAS.setTranslateY(-50);

        totalGABUNGKOMUNITAS = new TextField("0");
        totalGABUNGKOMUNITAS.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalGABUNGKOMUNITAS.setTranslateX(-300);
        totalGABUNGKOMUNITAS.setTranslateY(-50);
        totalGABUNGKOMUNITAS.setMaxWidth(100);
        totalGABUNGKOMUNITAS.setEditable(false);
        totalGABUNGKOMUNITAS.setAlignment(Pos.CENTER);
        totalGABUNGKOMUNITAS.textProperty().bind(Bindings.size(tableAllKomunitasCustomer.getItems()).asString());



        //table4
        tableAllLayananKebersihanCustomer = new TableView<>();

        TableColumn<AllLayananKebersihanCustomer, String> nomorProperti4 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti4.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti4.setPrefWidth(240);

        TableColumn<AllLayananKebersihanCustomer, String> idPengakutan4 = new TableColumn<>("ID PENGANGKUTAN");
        idPengakutan4.setCellValueFactory(cellData -> cellData.getValue().id_PengangkutanProperty());
        idPengakutan4.setPrefWidth(240);

        TableColumn<AllLayananKebersihanCustomer, String> hariOperasional4 = new TableColumn<>("HARI OPERASIONAL");
        hariOperasional4.setCellValueFactory(cellData -> cellData.getValue().hari_OperasionalProperty());
        hariOperasional4.setPrefWidth(240);

        TableColumn<AllLayananKebersihanCustomer, String> jamOperasional4 = new TableColumn<>("JAM OPERASIONAL");
        jamOperasional4.setCellValueFactory(cellData -> cellData.getValue().jam_OperasionalProperty());
        jamOperasional4.setPrefWidth(240);

        TableColumn<AllLayananKebersihanCustomer, String> jenisTruk4 = new TableColumn<>("JENIS TRUK");
        jenisTruk4.setCellValueFactory(cellData -> cellData.getValue().jenis_TrukProperty());
        jenisTruk4.setPrefWidth(240);

        tableAllLayananKebersihanCustomer.getColumns().addAll(
                nomorProperti4,
                idPengakutan4,
                hariOperasional4,
                jamOperasional4,
                jenisTruk4
        );

                tableAllLayananKebersihanCustomer.setTranslateY(400);
        tableAllLayananKebersihanCustomer.setMaxWidth(1200);
        tableAllLayananKebersihanCustomer.setMaxHeight(420);
        tableAllLayananKebersihanCustomer.setEditable(false);


        berhenti2 = new Button("BERHENTI");
        berhenti2.setStyle("-fx-background-color: #ff2121; -fx-font-size: 17px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        berhenti2.setTranslateX(0);
        berhenti2.setTranslateY(660);
        berhenti2.setMaxWidth(150);


        texttotalKEBERSIHAN = new Text("TOTAL KEBERSIHAN : " +
                "\n (YANG BERLANGGANAN)");
        texttotalKEBERSIHAN.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalKEBERSIHAN.setTranslateX(-500);
        texttotalKEBERSIHAN.setTranslateY(800);

        totalKEBERSIHAN = new TextField("0");
        totalKEBERSIHAN.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalKEBERSIHAN.setTranslateX(-300);
        totalKEBERSIHAN.setTranslateY(800);
        totalKEBERSIHAN.setMaxWidth(100);
        totalKEBERSIHAN.setEditable(false);
        totalKEBERSIHAN.setAlignment(Pos.CENTER);
        totalKEBERSIHAN.textProperty().bind(Bindings.size(tableAllLayananKebersihanCustomer.getItems()).asString());



        //tableRekap
        Text rekapCustomer = new Text("REKAP");
        rekapCustomer.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 36px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        rekapCustomer.setTextAlignment(TextAlignment.CENTER);
        rekapCustomer.setTranslateX(0);
        rekapCustomer.setTranslateY(1200);

        Text comingsoon = new Text("-----------------------------------------------------------" +
                "\n\nCOMING SOON " +
                "\n\n\n(SAMPAI JUMPA DI PENGEMBANGAN SELANJUTNYA)" +
                "\n\n\n\n-----------------------------------------------------------");
        comingsoon.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 42px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        comingsoon.setTextAlignment(TextAlignment.CENTER);
        comingsoon.setTranslateX(0);
        comingsoon.setTranslateY(2000);


        tableRekapCustomer = new TableView<>();

        TableColumn<RekapCustomer, String> totalPropertiCustomer = new TableColumn<>("TOTAL PROPERTI DIBELI");
        totalPropertiCustomer.setCellValueFactory(cellData -> cellData.getValue().totalPropertiDibeliProperty());
        totalPropertiCustomer.setPrefWidth(300);

        TableColumn<RekapCustomer, String> totalFasilitasCustomer = new TableColumn<>("TOTAL FASILITAS DIAKSES");
        totalFasilitasCustomer.setCellValueFactory(cellData -> cellData.getValue().totalFasilitasDiaksesProperty());
        totalFasilitasCustomer.setPrefWidth(300);

        TableColumn<RekapCustomer, String> totalKomunitasCustomer = new TableColumn<>("TOTAL KOMUNITAS DIIKUTI");
        totalKomunitasCustomer.setCellValueFactory(cellData -> cellData.getValue().totalKomunitasDIikutiProperty());
        totalKomunitasCustomer.setPrefWidth(300);

        TableColumn<RekapCustomer, String> totalKebersihanCustomer = new TableColumn<>("TOTAL KEBERSIHAN");
        totalKebersihanCustomer.setCellValueFactory(cellData -> cellData.getValue().totalKebersihanLanggananProperty());
        totalKebersihanCustomer.setPrefWidth(300);

        // Menambahkan kolom-kolom ke dalam TableView
        tableRekapCustomer.getColumns().addAll(
                totalPropertiCustomer,
                totalFasilitasCustomer,
                totalKomunitasCustomer,
                totalKebersihanCustomer
        );
        tableRekapCustomer.setTranslateY(1300);
        tableRekapCustomer.setMaxWidth(1200);
        tableRekapCustomer.setMaxHeight(60);
        tableRekapCustomer.setEditable(false);



        //main Layout

        navigasikiri = new StackPane();
        navigasikiri.getChildren().addAll(navigasi,logo,navGridPane, logout);

        contentkanan = new StackPane();
        contentkanan.getChildren().addAll(dashBoardtxt,garisdashBoardtxt,username123,lingkaranActive,
                tableTotalPropertiYangDibeli,cardDownlaod,downloadExcel,excel1,jual,texttotalDIBELI,totalPropertiDIBELI,
                tableAllFasilitasCustomer,berhenti1,texttotalAKSESFASILITAS,totalAKSESFASILITAS,
                tableAllKomunitasCustomer,keluar,texttotalGABUNGKOMUNITAS,totalGABUNGKOMUNITAS,
                tableAllLayananKebersihanCustomer,berhenti2,texttotalKEBERSIHAN,totalKEBERSIHAN,
                tableRekapCustomer,rekapCustomer,comingsoon
                );

        all = new HBox(navigasikiri,contentkanan);

        scrollPane = new ScrollPane();
        scrollPane.setContent(all);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        Scene scene = new Scene(scrollPane);

        stage.setTitle("Customer Ownership");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();

        //SQLTABLE
        getTable1(username);
        getTable2(username);
        getTable3(username);
        getTable4(username);
        getRekapCustomer(username);

        jual.setOnAction(event -> {
            TotalPropertiYangDibeli selectedProperti = tableTotalPropertiYangDibeli.getSelectionModel().getSelectedItem();

            if (selectedProperti != null) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Query untuk mengecek keberadaan data terkait di tabel-tabel
                    String checkMBFUSQL = "SELECT COUNT(*) FROM ARAYALANDBASDAT.MBFU WHERE INFOPROPERTI_NO_PR = ?";
                    String checkMBKMSQL = "SELECT COUNT(*) FROM ARAYALANDBASDAT.MBKM WHERE INFOPROPERTI_NO_PR = ?";
                    String checkLPSSQL = "SELECT COUNT(*) FROM ARAYALANDBASDAT.LPS WHERE INFOPROPERTI_NO_PR = ?";

                    // Prepare statements untuk pengecekan
                    PreparedStatement checkMBFU = conn.prepareStatement(checkMBFUSQL);
                    PreparedStatement checkMBKM = conn.prepareStatement(checkMBKMSQL);
                    PreparedStatement checkLPS = conn.prepareStatement(checkLPSSQL);

                    // Set parameter untuk pengecekan
                    checkMBFU.setString(1, selectedProperti.getNomor_Properti());
                    checkMBKM.setString(1, selectedProperti.getNomor_Properti());
                    checkLPS.setString(1, selectedProperti.getNomor_Properti());

                    // Eksekusi query pengecekan
                    ResultSet rsMBFU = checkMBFU.executeQuery();
                    ResultSet rsMBKM = checkMBKM.executeQuery();
                    ResultSet rsLPS = checkLPS.executeQuery();

                    rsMBFU.next();
                    rsMBKM.next();
                    rsLPS.next();

                    boolean existsInMBFU = rsMBFU.getInt(1) > 0;
                    boolean existsInMBKM = rsMBKM.getInt(1) > 0;
                    boolean existsInLPS = rsLPS.getInt(1) > 0;

                    // Jika properti ada di tabel-tabel terkait, lakukan penghapusan
                    if (existsInMBFU || existsInMBKM || existsInLPS) {
                        // Query untuk menghapus dari database
                        String deleteMBFUSQL = "DELETE FROM ARAYALANDBASDAT.MBFU WHERE INFOPROPERTI_NO_PR = ?";
                        String deleteMBKMSQL = "DELETE FROM ARAYALANDBASDAT.MBKM WHERE INFOPROPERTI_NO_PR = ?";
                        String deleteLPSSQL = "DELETE FROM ARAYALANDBASDAT.LPS WHERE INFOPROPERTI_NO_PR = ?";
                        String deleteSQL = "DELETE FROM ARAYALANDBASDAT.INFOPROPERTI WHERE PROPERTI_NO_PR = ?";
                        String deleteSQLTR = "DELETE FROM ARAYALANDBASDAT.TRANSAKSI WHERE ID_TR = ?";

                        // Prepare statements untuk penghapusan
                        PreparedStatement pstmtMBFU = conn.prepareStatement(deleteMBFUSQL);
                        PreparedStatement pstmtMBKM = conn.prepareStatement(deleteMBKMSQL);
                        PreparedStatement pstmtLPS = conn.prepareStatement(deleteLPSSQL);
                        PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                        PreparedStatement pstmtTR = conn.prepareStatement(deleteSQLTR);

                        // Set parameter untuk penghapusan
                        pstmtMBFU.setString(1, selectedProperti.getNomor_Properti());
                        pstmtMBKM.setString(1, selectedProperti.getNomor_Properti());
                        pstmtLPS.setString(1, selectedProperti.getNomor_Properti());
                        pstmt.setString(1, selectedProperti.getNomor_Properti());
                        pstmtTR.setString(1,selectedProperti.getId_Transaksi());

                        // Melakukan penghapusan data dari tabel-tabel terkait
                        int affectedRowsMBFU = pstmtMBFU.executeUpdate();
                        int affectedRowsMBKM = pstmtMBKM.executeUpdate();
                        int affectedRowsLPS = pstmtLPS.executeUpdate();
                        int affectedRows = pstmt.executeUpdate();
                        int affectedRowsTR = pstmtTR.executeUpdate();

                        // Memeriksa apakah semua penghapusan berhasil
                        if (affectedRowsMBFU > 0 || affectedRowsMBKM > 0 || affectedRowsLPS > 0 || affectedRows > 0 || affectedRowsTR > 0) {
                            showSucces("Delete Data", "Properti Berhasil Dijual");
                            tableTotalPropertiYangDibeli.getItems().remove(selectedProperti);

                            // Membersihkan dan memuat ulang data pada tabel rekap dan lainnya
                            tableRekapCustomer.getItems().clear();
                            getRekapCustomer(username);

                            tableAllFasilitasCustomer.getItems().clear();
                            getTable2(username);

                            tableAllKomunitasCustomer.getItems().clear();
                            getTable3(username);

                            tableAllLayananKebersihanCustomer.getItems().clear();
                            getTable4(username);
                        } else {
                            showAlert("Error Delete", "Gagal Menjual Properti.");
                        }
                    } else {
                        // Properti tidak ditemukan di tabel terkait, langsung hapus dari tabel utama
                        String deleteSQL = "DELETE FROM ARAYALANDBASDAT.INFOPROPERTI WHERE PROPERTI_NO_PR = ?";
                        String deleteSQLTR = "DELETE FROM ARAYALANDBASDAT.TRANSAKSI WHERE ID_TR = ?";

                        PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                        PreparedStatement pstmtTR = conn.prepareStatement(deleteSQLTR);

                        pstmt.setString(1, selectedProperti.getNomor_Properti());
                        pstmtTR.setString(1,selectedProperti.getId_Transaksi());

                        int affectedRows = pstmt.executeUpdate();
                        int affectedRowsTR = pstmtTR.executeUpdate();

                        if (affectedRows > 0 && affectedRowsTR > 0) {
                            showSucces("Delete Data", "Properti Berhasil Dijual");
                            tableTotalPropertiYangDibeli.getItems().remove(selectedProperti);

                            // Membersihkan dan memuat ulang data pada tabel rekap dan lainnya
                            tableRekapCustomer.getItems().clear();
                            getRekapCustomer(username);

                            tableAllFasilitasCustomer.getItems().clear();
                            getTable2(username);

                            tableAllKomunitasCustomer.getItems().clear();
                            getTable3(username);

                            tableAllLayananKebersihanCustomer.getItems().clear();
                            getTable4(username);
                        } else {
                            showAlert("Error Delete", "Gagal Menjual Properti.");
                        }
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Choose Line", "Pilih baris terlebih dahulu");
            }
        });

        excel1.setOnMouseClicked(mouseEvent -> {
            // Mengatur nama file CSV yang akan dibuat
            String csvFilePath = generateUniqueFileName("LAPORAN_KEPEMILIKAN.csv");

            try (PrintWriter writer = new PrintWriter(new File(csvFilePath))) {

                writer.println("LAPORAN KEPEMILIKAN  " +username+"  "+ LocalDate.now());

                writer.println("Total Properti Yang Dibeli");

                StringBuilder headerTotalPropertiYangDibeli = new StringBuilder();
                headerTotalPropertiYangDibeli.append("NOMOR PROPERTI,");
                headerTotalPropertiYangDibeli.append("NAMA PROPERTI,");
                headerTotalPropertiYangDibeli.append("AREA PROPERTI,");
                headerTotalPropertiYangDibeli.append("LUAS TANAH,");
                headerTotalPropertiYangDibeli.append("HARGA TANAH,");
                headerTotalPropertiYangDibeli.append("LUAS BANGUNAN,");
                headerTotalPropertiYangDibeli.append("HARGA BANGUNAN,");
                headerTotalPropertiYangDibeli.append("PPN 10%,");
                headerTotalPropertiYangDibeli.append("HARGA TOTAL,");
                headerTotalPropertiYangDibeli.append("ID TRANSAKSI,");
                headerTotalPropertiYangDibeli.append("STATUS PROPERTI,");
                writer.println(headerTotalPropertiYangDibeli);

                ObservableList<TotalPropertiYangDibeli> itemTotalPropertiDibeli = tableTotalPropertiYangDibeli.getItems();
                for (TotalPropertiYangDibeli item : itemTotalPropertiDibeli) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getNama_Properti()).append(",");
                    dataLine.append(item.getLuas_Tanah_Properti()).append(",");
                    dataLine.append(item.getHarga_Tanah_Properti()).append(",");
                    dataLine.append(item.getLuas_Bangunan_Properti()).append(",");
                    dataLine.append(item.getHarga_Bangunan_Properti()).append(",");
                    dataLine.append(item.getPpn_Properti()).append(",");
                    dataLine.append(item.getHarga_Total_Properti()).append(",");
                    dataLine.append(item.getId_Transaksi()).append(",");
                    dataLine.append(item.getStatus_Properti()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Fasilitas Yang Diakses");


                StringBuilder headerAllFasilitas = new StringBuilder();
                headerAllFasilitas.append("NOMOR PROPERTI,");
                headerAllFasilitas.append("NAMA FASILITAS,");
                headerAllFasilitas.append("HARI OPERASIONAL,");
                headerAllFasilitas.append("JAM OPERASIONAL,");
                writer.println(headerAllFasilitas);

                ObservableList<AllFasilitasCustomer> itemAllFasilitas = tableAllFasilitasCustomer.getItems();
                for (AllFasilitasCustomer item : itemAllFasilitas) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getNama_Properti()).append(",");
                    dataLine.append(item.getHari_Operasional()).append(",");
                    dataLine.append(item.getJam_Operasional()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Komunitas Yang Diikuti");


                StringBuilder headerAllKomunitas = new StringBuilder();
                headerAllKomunitas.append("NOMOR PROPERTI,");
                headerAllKomunitas.append("NAMA KOMUNITAS,");
                headerAllKomunitas.append("AGENDA ,");
                writer.println(headerAllKomunitas);

                ObservableList<AllKomunitasCustomer> itemAllKomunitas = tableAllKomunitasCustomer.getItems();
                for (AllKomunitasCustomer item : itemAllKomunitas) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getNama_Komunitas()).append(",");
                    dataLine.append(item.getAgenda_Komunitas()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Langganan Layanan Kebersihan");

                StringBuilder headerAllCS = new StringBuilder();
                headerAllCS.append("NOMOR PROPERTI,");
                headerAllCS.append("ID PENGANGKUTAN,");
                headerAllCS.append("HARI OPERASIONAL,");
                headerAllCS.append("JAM OPERASIONAL,");
                headerAllCS.append("JENIS TRUK,");

                writer.println(headerAllCS);

                ObservableList<AllLayananKebersihanCustomer> itemAllCS = tableAllLayananKebersihanCustomer.getItems();
                for (AllLayananKebersihanCustomer item : itemAllCS) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getId_Pengangkutan()).append(",");
                    dataLine.append(item.getHari_Operasional()).append(",");
                    dataLine.append(item.getJam_Operasional()).append(",");
                    dataLine.append(item.getJenis_Truk()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Langganan Layanan Kebersihan");

                StringBuilder headerRekapCustomer = new StringBuilder();
                headerRekapCustomer.append("TOTAL PROPERTI DIBELI,");
                headerRekapCustomer.append("TOTAL FASILITAS DIAKSES,");
                headerRekapCustomer.append("TOTAL KOMUNITAS DIIKUTI,");
                headerRekapCustomer.append("TOTAL LANGGANAN LAYANAN KEBERSIHAN,");

                writer.println(headerRekapCustomer);

                ObservableList<RekapCustomer> itemRekapCustomer = tableRekapCustomer.getItems();
                for (RekapCustomer item : itemRekapCustomer) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getTotalPropertiDibeli()).append(",");
                    dataLine.append(item.getTotalFasilitasDiakses()).append(",");
                    dataLine.append(item.getTotalKomunitasDIikuti()).append(",");
                    dataLine.append(item.getTotalKebersihanLangganan()).append(",");
                    writer.println(dataLine);
                }

                showSucces("CSV FILE", "Berhasil Mendownload " + csvFilePath);
                Runtime.getRuntime().exec("cmd /c start " + csvFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });




        berhenti1.setOnAction(event -> {
            // Mendapatkan baris yang dipilih
            AllFasilitasCustomer selectedProperti = tableAllFasilitasCustomer.getSelectionModel().getSelectedItem();

            if (selectedProperti != null) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Query untuk menghapus dari database
                    String deleteSQL = "DELETE FROM ARAYALANDBASDAT.MBFU WHERE INFOPROPERTI_NO_PR = ?";
                    PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                    pstmt.setString(1, selectedProperti.getNomor_Properti());

                    // Melakukan penghapusan dari database
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        showSucces("Delete Data","Berhasil Berhenti Mengakses Fasilitas");
                        tableAllFasilitasCustomer.getItems().remove(selectedProperti);
                        tableRekapCustomer.getItems().clear();
                        getRekapCustomer(username);


                    } else {
                        showAlert("Error Delete","Tidak Berhasil Berhenti Mengakses Fasilitas");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Choose Line","Pilih baris terlebih dahulu");
            }

        });

        keluar.setOnAction(event -> {

            // Mendapatkan baris yang dipilih
            AllKomunitasCustomer selectedProperti = tableAllKomunitasCustomer.getSelectionModel().getSelectedItem();

            if (selectedProperti != null) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Query untuk menghapus dari database
                    String deleteSQL = "DELETE FROM ARAYALANDBASDAT.MBKM WHERE INFOPROPERTI_NO_PR = ?";
                    PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                    pstmt.setString(1, selectedProperti.getNomor_Properti());

                    // Melakukan penghapusan dari database
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        showSucces("Delete Data","Berhasil Keluar Dari Komunitas");
                        tableAllKomunitasCustomer.getItems().remove(selectedProperti);
                        tableRekapCustomer.getItems().clear();
                        getRekapCustomer(username);


                    } else {
                        showAlert("Error Delete","Tidak Berhasil Keluar Dari Komunitas");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Choose Line","Pilih baris terlebih dahulu");
            }

        });

        berhenti2.setOnAction(event -> {
            AllLayananKebersihanCustomer selectedProperti = tableAllLayananKebersihanCustomer.getSelectionModel().getSelectedItem();

            if (selectedProperti != null) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {

                    String deleteSQL = "DELETE FROM ARAYALANDBASDAT.LPS WHERE INFOPROPERTI_NO_PR = ?";
                    PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                    pstmt.setString(1, selectedProperti.getNomor_Properti());

                    // Melakukan penghapusan dari database
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        showSucces("Delete Data","Berhasil Berhenti Berlangganan Kebersihan");
                        tableAllLayananKebersihanCustomer.getItems().remove(selectedProperti);
                        tableRekapCustomer.getItems().clear();
                        getRekapCustomer(username);


                    } else {
                        showAlert("Error Delete","Tidak Berhasil Berhenti Berlangganan Kebersihan");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Choose Line","Pilih baris terlebih dahulu");
            }

        });

        iconBeliProperti.setOnMouseClicked(mouseEvent -> {
            CustomerProperty customerProperty = new CustomerProperty();
            try {
                Stage newStage = new Stage();
                customerProperty.setUsername(username);
                customerProperty.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        iconAksesFasilitas.setOnMouseClicked(mouseEvent -> {
            CustomerFacility customerFacility = new CustomerFacility();
            try {
                Stage newStage = new Stage();
                customerFacility.setUsername(username);
                customerFacility.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        iconJoinKomunitas.setOnMouseClicked(mouseEvent -> {
            CustomerCommunity customerCommunity = new CustomerCommunity();
            try {
                Stage newStage = new Stage();
                customerCommunity.setUsername(username);
                customerCommunity.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        iconOwnership.setOnMouseClicked(mouseEvent -> {
            CustomerOwnership customerOwnership = new CustomerOwnership();
            showSucces("Already in there","Anda sudah berada dihalaman Properti Saya");
            customerOwnership.setUsername(username);
        });

        iconBerlanggananCS.setOnMouseClicked(mouseEvent -> {
            CustomerCS customerCS = new CustomerCS();
            try {
                Stage newStage = new Stage();
                customerCS.setUsername(username);
                customerCS.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        logout.setOnMouseClicked(mouseEvent -> {
            MainLogin mainLogin = new MainLogin();
            try {
                Stage newStage = new Stage();
                mainLogin.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void showSucces(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }


    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private String username;

    public void setUsername(String username) {
        this.username = username;
    }

    public void getTable1(String accountUsnmAc) {
        String selectSQL = "SELECT PR.PROPERTI_NO_PR, P.NAMA_PR, P.LUASTANAH, P.HARGATANAH, P.LUASBG, P.HARGABANGUNAN, P.PPN, P.HARGA_TOTAL, PR.TRANSAKSI_ID_TR, PR.STATUS_PR " +
                "FROM ARAYALANDBASDAT.INFOPROPERTI PR " +
                "INNER JOIN ARAYALANDBASDAT.PROPERTI P ON PR.PROPERTI_NO_PR = P.NO_PR " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            pstmt.setString(1, accountUsnmAc);
            ResultSet resultSet = pstmt.executeQuery();

            List<TotalPropertiYangDibeli> totalPropertiYangDibelis = new ArrayList<>();
            while (resultSet.next()) {
                TotalPropertiYangDibeli totalPropertiYangDibeli = new TotalPropertiYangDibeli();

                totalPropertiYangDibeli.setNomor_Properti(resultSet.getString("PROPERTI_NO_PR"));
                totalPropertiYangDibeli.setNama_Properti(resultSet.getString("NAMA_PR"));
                totalPropertiYangDibeli.setLuas_Tanah_Properti(resultSet.getDouble("LUASTANAH"));
                totalPropertiYangDibeli.setHarga_Tanah_Properti(resultSet.getDouble("HARGATANAH"));
                totalPropertiYangDibeli.setLuas_Bangunan_Properti(resultSet.getDouble("LUASBG"));
                totalPropertiYangDibeli.setHarga_Bangunan_Properti(resultSet.getDouble("HARGABANGUNAN"));
                totalPropertiYangDibeli.setPpn_Properti(resultSet.getDouble("PPN"));
                totalPropertiYangDibeli.setHarga_Total_Properti(resultSet.getDouble("HARGA_TOTAL"));
                totalPropertiYangDibeli.setId_Transaksi(resultSet.getString("TRANSAKSI_ID_TR"));
                totalPropertiYangDibeli.setStatus_Properti(resultSet.getString("STATUS_PR"));

                totalPropertiYangDibelis.add(totalPropertiYangDibeli);
            }

            tableTotalPropertiYangDibeli.getItems().addAll(totalPropertiYangDibelis);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



    public void getTable2(String accountUsnmAc) {
        String selectSQL = "SELECT PR.PROPERTI_NO_PR, MF.FASILITAS_NAMA_FU, F.HARI_FU, F.JAM_FU " +
                "FROM ARAYALANDBASDAT.MBFU MF " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON MF.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.FASILITAS F ON MF.FASILITAS_NAMA_FU = F.NAMA_FU " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            pstmt.setString(1, accountUsnmAc);
            ResultSet resultSet = pstmt.executeQuery();

            List<AllFasilitasCustomer> allFasilitasCustomers = new ArrayList<>();
            while (resultSet.next()) {
                AllFasilitasCustomer allFasilitasCustomer = new AllFasilitasCustomer();

                allFasilitasCustomer.setNomor_Properti(resultSet.getString("PROPERTI_NO_PR"));
                allFasilitasCustomer.setNama_Properti(resultSet.getString("FASILITAS_NAMA_FU"));
                allFasilitasCustomer.setHari_Operasional(resultSet.getString("HARI_FU"));
                allFasilitasCustomer.setJam_Operasional(resultSet.getString("JAM_FU"));


                allFasilitasCustomers.add(allFasilitasCustomer);
            }

            tableAllFasilitasCustomer.getItems().addAll(allFasilitasCustomers);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable3(String accountUsnmAc) {
        String selectSQL = "SELECT PR.PROPERTI_NO_PR, MM.KOMUNITAS_NAMA_KM, K.AGENDA_KM " +
                "FROM ARAYALANDBASDAT.MBKM MM " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON MM.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.KOMUNITAS K ON MM.KOMUNITAS_NAMA_KM = K.NAMA_KM " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            pstmt.setString(1, accountUsnmAc);
            ResultSet resultSet = pstmt.executeQuery();

            List<AllKomunitasCustomer> allKomunitasCustomers = new ArrayList<>();
            while (resultSet.next()) {
                AllKomunitasCustomer allKomunitasCustomer = new AllKomunitasCustomer();

                allKomunitasCustomer.setNomor_Properti(resultSet.getString("PROPERTI_NO_PR"));
                allKomunitasCustomer.setNama_Komunitas(resultSet.getString("KOMUNITAS_NAMA_KM"));
                allKomunitasCustomer.setAgenda_Komunitas(resultSet.getString("AGENDA_KM"));

                allKomunitasCustomers.add(allKomunitasCustomer);
            }

            tableAllKomunitasCustomer.getItems().addAll(allKomunitasCustomers);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable4(String accountUsnmAc) {
        String selectSQL = "SELECT PR.PROPERTI_NO_PR, L.KEBERSIHAN_ID_KB, KB.HARI_KB, KB.JAM_KB, KB.JENIS_TRUK " +
                "FROM ARAYALANDBASDAT.LPS L " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON L.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.KEBERSIHAN KB ON L.KEBERSIHAN_ID_KB = KB.ID_KB " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            pstmt.setString(1, accountUsnmAc);
            ResultSet resultSet = pstmt.executeQuery();

            List<AllLayananKebersihanCustomer> allLayananKebersihanCustomers = new ArrayList<>();
            while (resultSet.next()) {
                AllLayananKebersihanCustomer allLayananKebersihanCustomer = new AllLayananKebersihanCustomer();

                allLayananKebersihanCustomer.setNomor_Properti(resultSet.getString("PROPERTI_NO_PR"));
                allLayananKebersihanCustomer.setId_Pengangkutan(resultSet.getString("KEBERSIHAN_ID_KB"));
                allLayananKebersihanCustomer.setHari_Operasional(resultSet.getString("HARI_KB"));
                allLayananKebersihanCustomer.setJam_Operasional(resultSet.getString("JAM_KB"));
                allLayananKebersihanCustomer.setJenis_Truk(resultSet.getString("JENIS_TRUK"));

                allLayananKebersihanCustomers.add(allLayananKebersihanCustomer);
            }

            tableAllLayananKebersihanCustomer.getItems().addAll(allLayananKebersihanCustomers);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void getRekapCustomer(String accountUsnmAc) {
        String countPropertiSQL = "SELECT COUNT(*) AS TOTAL_PROPERTI " +
                "FROM ARAYALANDBASDAT.INFOPROPERTI PR " +
                "INNER JOIN ARAYALANDBASDAT.PROPERTI P ON PR.PROPERTI_NO_PR = P.NO_PR " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";

        String countFasilitasSQL = "SELECT COUNT(*) AS TOTAL_FASILITAS " +
                "FROM ARAYALANDBASDAT.MBFU MF " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON MF.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.FASILITAS F ON MF.FASILITAS_NAMA_FU = F.NAMA_FU " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";

        String countKomunitasSQL = "SELECT COUNT(*) AS TOTAL_KOMUNITAS " +
                "FROM ARAYALANDBASDAT.MBKM MM " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON MM.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.KOMUNITAS K ON MM.KOMUNITAS_NAMA_KM = K.NAMA_KM " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";

        String countKebersihanSQL = "SELECT COUNT(*) AS TOTAL_KEBERSIHAN " +
                "FROM ARAYALANDBASDAT.LPS L " +
                "INNER JOIN ARAYALANDBASDAT.INFOPROPERTI PR ON L.INFOPROPERTI_NO_PR = PR.PROPERTI_NO_PR " +
                "INNER JOIN ARAYALANDBASDAT.KEBERSIHAN KB ON L.KEBERSIHAN_ID_KB = KB.ID_KB " +
                "WHERE PR.ACCOUNT_USNM_AC = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            PreparedStatement pstmtProperti = conn.prepareStatement(countPropertiSQL);
            PreparedStatement pstmtFasilitas = conn.prepareStatement(countFasilitasSQL);
            PreparedStatement pstmtKomunitas = conn.prepareStatement(countKomunitasSQL);
            PreparedStatement pstmtKebersihan = conn.prepareStatement(countKebersihanSQL);

            pstmtProperti.setString(1, accountUsnmAc);
            pstmtFasilitas.setString(1, accountUsnmAc);
            pstmtKomunitas.setString(1, accountUsnmAc);
            pstmtKebersihan.setString(1, accountUsnmAc);

            ResultSet resultSetProperti = pstmtProperti.executeQuery();
            ResultSet resultSetFasilitas = pstmtFasilitas.executeQuery();
            ResultSet resultSetKomunitas = pstmtKomunitas.executeQuery();
            ResultSet resultSetKebersihan = pstmtKebersihan.executeQuery();

            RekapCustomer rekapCustomer = new RekapCustomer();

            if (resultSetProperti.next()) {
                rekapCustomer.setTotalPropertiDibeli(resultSetProperti.getString("TOTAL_PROPERTI"));
            }
            if (resultSetFasilitas.next()) {
                rekapCustomer.setTotalFasilitasDiakses(resultSetFasilitas.getString("TOTAL_FASILITAS"));
            }
            if (resultSetKomunitas.next()) {
                rekapCustomer.setTotalKomunitasDIikuti(resultSetKomunitas.getString("TOTAL_KOMUNITAS"));
            }
            if (resultSetKebersihan.next()) {
                rekapCustomer.setTotalKebersihanLangganan(resultSetKebersihan.getString("TOTAL_KEBERSIHAN"));
            }

            tableRekapCustomer.getItems().add(rekapCustomer);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static String generateUniqueFileName(String baseFileName) {
        String fileName = baseFileName;
        File file = new File(fileName);
        while (file.exists()) {
            fileCounter++;
            int extensionIndex = baseFileName.lastIndexOf('.');
            if (extensionIndex == -1) {
                fileName = baseFileName + "(" + fileCounter + ")";
            } else {
                fileName = baseFileName.substring(0, extensionIndex) + "(" + fileCounter + ")" +
                        baseFileName.substring(extensionIndex);
            }
            file = new File(fileName);
        }
        return fileName;
    }

}
