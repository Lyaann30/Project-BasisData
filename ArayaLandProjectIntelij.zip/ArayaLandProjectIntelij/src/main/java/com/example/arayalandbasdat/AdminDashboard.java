package com.example.arayalandbasdat;

import javafx.animation.*;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.beans.property.DoubleProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.Glow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.application.HostServices;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


class TotalPropertiYangDijual {
    private StringProperty nomorProperti;
    private StringProperty namaProperti;
    private StringProperty areaProperti;
    private DoubleProperty luasTanahProperti;
    private DoubleProperty hargaTanahProperti;
    private DoubleProperty luasBangunanProperti;
    private DoubleProperty hargaBangunanProperti;
    private DoubleProperty ppnProperti;
    private DoubleProperty hargaTotalProperti;

    public TotalPropertiYangDijual() {
        this.nomorProperti = new SimpleStringProperty();
        this.namaProperti = new SimpleStringProperty();
        this.areaProperti = new SimpleStringProperty();
        this.luasTanahProperti = new SimpleDoubleProperty();
        this.hargaTanahProperti = new SimpleDoubleProperty();
        this.luasBangunanProperti = new SimpleDoubleProperty();
        this.hargaBangunanProperti = new SimpleDoubleProperty();
        this.ppnProperti = new SimpleDoubleProperty();
        this.hargaTotalProperti = new SimpleDoubleProperty();
    }

    // Getter dan Setter untuk nomorProperti
    public String getNomorProperti() {
        return nomorProperti.get();
    }

    public void setNomorProperti(String nomorProperti) {
        this.nomorProperti.set(nomorProperti);
    }

    public StringProperty nomorPropertiProperty() {
        return nomorProperti;
    }

    // Getter dan Setter untuk namaProperti
    public String getNamaProperti() {
        return namaProperti.get();
    }

    public void setNamaProperti(String namaProperti) {
        this.namaProperti.set(namaProperti);
    }

    public StringProperty namaPropertiProperty() {
        return namaProperti;
    }

    // Getter dan Setter untuk areaProperti
    public String getAreaProperti() {
        return areaProperti.get();
    }

    public void setAreaProperti(String areaProperti) {
        this.areaProperti.set(areaProperti);
    }

    public StringProperty areaPropertiProperty() {
        return areaProperti;
    }

    // Getter dan Setter untuk luasTanahProperti
    public double getLuasTanahProperti() {
        return luasTanahProperti.get();
    }

    public void setLuasTanahProperti(double luasTanahProperti) {
        this.luasTanahProperti.set(luasTanahProperti);
    }

    public DoubleProperty luasTanahPropertiProperty() {
        return luasTanahProperti;
    }

    // Getter dan Setter untuk hargaTanahProperti
    public double getHargaTanahProperti() {
        return hargaTanahProperti.get();
    }

    public void setHargaTanahProperti(double hargaTanahProperti) {
        this.hargaTanahProperti.set(hargaTanahProperti);
    }

    public DoubleProperty hargaTanahPropertiProperty() {
        return hargaTanahProperti;
    }

    // Getter dan Setter untuk luasBangunanProperti
    public double getLuasBangunanProperti() {
        return luasBangunanProperti.get();
    }

    public void setLuasBangunanProperti(double luasBangunanProperti) {
        this.luasBangunanProperti.set(luasBangunanProperti);
    }

    public DoubleProperty luasBangunanPropertiProperty() {
        return luasBangunanProperti;
    }

    // Getter dan Setter untuk hargaBangunanProperti
    public double getHargaBangunanProperti() {
        return hargaBangunanProperti.get();
    }

    public void setHargaBangunanProperti(double hargaBangunanProperti) {
        this.hargaBangunanProperti.set(hargaBangunanProperti);
    }

    public DoubleProperty hargaBangunanPropertiProperty() {
        return hargaBangunanProperti;
    }

    // Getter dan Setter untuk ppnProperti
    public double getPpnProperti() {
        return ppnProperti.get();
    }

    public void setPpnProperti(double ppnProperti) {
        this.ppnProperti.set(ppnProperti);
    }

    public DoubleProperty ppnPropertiProperty() {
        return ppnProperti;
    }

    // Getter dan Setter untuk hargaTotalProperti
    public double getHargaTotalProperti() {
        return hargaTotalProperti.get();
    }

    public void setHargaTotalProperti(double hargaTotalProperti) {
        this.hargaTotalProperti.set(hargaTotalProperti);
    }

    public DoubleProperty hargaTotalPropertiProperty() {
        return hargaTotalProperti;
    }
}

class TotalPropertiBelumTerjual{
    StringProperty nomor_Properti;
    StringProperty nama_Properti;
    StringProperty area_Properti;
    DoubleProperty luas_Tanah_Properti;
    DoubleProperty luas_Bangunan_Properti;

    public TotalPropertiBelumTerjual() {
        this.nomor_Properti = new SimpleStringProperty();
        this.nama_Properti = new SimpleStringProperty();
        this.area_Properti = new SimpleStringProperty();
        this.luas_Tanah_Properti = new SimpleDoubleProperty();
        this.luas_Bangunan_Properti = new SimpleDoubleProperty();
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getNama_Properti() {
        return nama_Properti.get();
    }

    public StringProperty nama_PropertiProperty() {
        return nama_Properti;
    }

    public void setNama_Properti(String nama_Properti) {
        this.nama_Properti.set(nama_Properti);
    }

    public String getArea_Properti() {
        return area_Properti.get();
    }

    public StringProperty area_PropertiProperty() {
        return area_Properti;
    }

    public void setArea_Properti(String area_Properti) {
        this.area_Properti.set(area_Properti);
    }

    public double getLuas_Tanah_Properti() {
        return luas_Tanah_Properti.get();
    }

    public DoubleProperty luas_Tanah_PropertiProperty() {
        return luas_Tanah_Properti;
    }

    public void setLuas_Tanah_Properti(double luas_Tanah_Properti) {
        this.luas_Tanah_Properti.set(luas_Tanah_Properti);
    }

    public double getLuas_Bangunan_Properti() {
        return luas_Bangunan_Properti.get();
    }

    public DoubleProperty luas_Bangunan_PropertiProperty() {
        return luas_Bangunan_Properti;
    }

    public void setLuas_Bangunan_Properti(double luas_Bangunan_Properti) {
        this.luas_Bangunan_Properti.set(luas_Bangunan_Properti);
    }
}


class TotalPropertiSudahTerjual {
    StringProperty username_Properti;
    StringProperty ID_Transaksi;
    StringProperty nomor_Properti;
    StringProperty nama_Properti;
    StringProperty area_Properti;
    DoubleProperty luas_Tanah_Properti;
    DoubleProperty luas_Bangunan_Properti;
    StringProperty status_Properti;

    public TotalPropertiSudahTerjual() {
        this.username_Properti = new SimpleStringProperty();
        this.ID_Transaksi = new SimpleStringProperty();
        this.nomor_Properti = new SimpleStringProperty();
        this.nama_Properti = new SimpleStringProperty();
        this.area_Properti = new SimpleStringProperty();
        this.luas_Tanah_Properti = new SimpleDoubleProperty();
        this.luas_Bangunan_Properti = new SimpleDoubleProperty();
        this.status_Properti = new SimpleStringProperty();
    }

    public String getUsername_Properti() {
        return username_Properti.get();
    }

    public StringProperty username_PropertiProperty() {
        return username_Properti;
    }

    public void setUsername_Properti(String username_Properti) {
        this.username_Properti.set(username_Properti);
    }

    public String getID_Transaksi() {
        return ID_Transaksi.get();
    }

    public StringProperty ID_TransaksiProperty() {
        return ID_Transaksi;
    }

    public void setID_Transaksi(String ID_Transaksi) {
        this.ID_Transaksi.set(ID_Transaksi);
    }

    public String getNomor_Properti() {
        return nomor_Properti.get();
    }

    public StringProperty nomor_PropertiProperty() {
        return nomor_Properti;
    }

    public void setNomor_Properti(String nomor_Properti) {
        this.nomor_Properti.set(nomor_Properti);
    }

    public String getNama_Properti() {
        return nama_Properti.get();
    }

    public StringProperty nama_PropertiProperty() {
        return nama_Properti;
    }

    public void setNama_Properti(String nama_Properti) {
        this.nama_Properti.set(nama_Properti);
    }

    public String getArea_Properti() {
        return area_Properti.get();
    }

    public StringProperty area_PropertiProperty() {
        return area_Properti;
    }

    public void setArea_Properti(String area_Properti) {
        this.area_Properti.set(area_Properti);
    }

    public double getLuas_Tanah_Properti() {
        return luas_Tanah_Properti.get();
    }

    public DoubleProperty luas_Tanah_PropertiProperty() {
        return luas_Tanah_Properti;
    }

    public void setLuas_Tanah_Properti(double luas_Tanah_Properti) {
        this.luas_Tanah_Properti.set(luas_Tanah_Properti);
    }

    public double getLuas_Bangunan_Properti() {
        return luas_Bangunan_Properti.get();
    }

    public DoubleProperty luas_Bangunan_PropertiProperty() {
        return luas_Bangunan_Properti;
    }

    public void setLuas_Bangunan_Properti(double luas_Bangunan_Properti) {
        this.luas_Bangunan_Properti.set(luas_Bangunan_Properti);
    }

    public String getStatus_Properti() {
        return status_Properti.get();
    }

    public StringProperty status_PropertiProperty() {
        return status_Properti;
    }

    public void setStatus_Properti(String status_Properti) {
        this.status_Properti.set(status_Properti);
    }
}

class AllFasilitas{
    StringProperty nama_Fasilitas;
    StringProperty hari_Operasional;
    StringProperty jam_Operasional;
    DoubleProperty kapasitas;
    DoubleProperty rating;

    public AllFasilitas() {
        this.nama_Fasilitas = new SimpleStringProperty();
        this.hari_Operasional = new SimpleStringProperty();
        this.jam_Operasional = new SimpleStringProperty();
        this.kapasitas = new SimpleDoubleProperty();
        this.rating = new SimpleDoubleProperty();
    }

    public String getNama_Fasilitas() {
        return nama_Fasilitas.get();
    }

    public StringProperty nama_FasilitasProperty() {
        return nama_Fasilitas;
    }

    public void setNama_Fasilitas(String nama_Fasilitas) {
        this.nama_Fasilitas.set(nama_Fasilitas);
    }

    public String getHari_Operasional() {
        return hari_Operasional.get();
    }

    public StringProperty hari_OperasionalProperty() {
        return hari_Operasional;
    }

    public void setHari_Operasional(String hari_Operasional) {
        this.hari_Operasional.set(hari_Operasional);
    }

    public String getJam_Operasional() {
        return jam_Operasional.get();
    }

    public StringProperty jam_OperasionalProperty() {
        return jam_Operasional;
    }

    public void setJam_Operasional(String jam_Operasional) {
        this.jam_Operasional.set(jam_Operasional);
    }

    public double getKapasitas() {
        return kapasitas.get();
    }

    public DoubleProperty kapasitasProperty() {
        return kapasitas;
    }

    public void setKapasitas(double kapasitas) {
        this.kapasitas.set(kapasitas);
    }

    public double getRating() {
        return rating.get();
    }

    public DoubleProperty ratingProperty() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating.set(rating);
    }
}

class AllKomunitas{
    StringProperty nama_Komunitas;
    StringProperty tanggal_Pendirian;
    StringProperty agenda_Komunitas;
    StringProperty syarat_Komunitas;

    public AllKomunitas() {
        this.nama_Komunitas = new SimpleStringProperty();
        this.tanggal_Pendirian = new SimpleStringProperty();
        this.agenda_Komunitas = new SimpleStringProperty();
        this.syarat_Komunitas = new SimpleStringProperty();
    }

    public String getNama_Komunitas() {
        return nama_Komunitas.get();
    }

    public StringProperty nama_KomunitasProperty() {
        return nama_Komunitas;
    }

    public void setNama_Komunitas(String nama_Komunitas) {
        this.nama_Komunitas.set(nama_Komunitas);
    }

    public String getTanggal_Pendirian() {
        return tanggal_Pendirian.get();
    }

    public StringProperty tanggal_PendirianProperty() {
        return tanggal_Pendirian;
    }

    public void setTanggal_Pendirian(String tanggal_Pendirian) {
        this.tanggal_Pendirian.set(tanggal_Pendirian);
    }

    public String getAgenda_Komunitas() {
        return agenda_Komunitas.get();
    }

    public StringProperty agenda_KomunitasProperty() {
        return agenda_Komunitas;
    }

    public void setAgenda_Komunitas(String agenda_Komunitas) {
        this.agenda_Komunitas.set(agenda_Komunitas);
    }

    public String getSyarat_Komunitas() {
        return syarat_Komunitas.get();
    }

    public StringProperty syarat_KomunitasProperty() {
        return syarat_Komunitas;
    }

    public void setSyarat_Komunitas(String syarat_Komunitas) {
        this.syarat_Komunitas.set(syarat_Komunitas);
    }
}

class AllLayananKebersihan{
    StringProperty id_Pengangkutan;
    StringProperty hari_Operasional;
    StringProperty jam_Operasional;
    StringProperty jenis_Truk;

    public AllLayananKebersihan() {
        this.id_Pengangkutan = new SimpleStringProperty();
        this.hari_Operasional = new SimpleStringProperty();
        this.jam_Operasional = new SimpleStringProperty();
        this.jenis_Truk = new SimpleStringProperty();
    }

    public String getId_Pengangkutan() {
        return id_Pengangkutan.get();
    }

    public StringProperty id_PengangkutanProperty() {
        return id_Pengangkutan;
    }

    public void setId_Pengangkutan(String id_Pengangkutan) {
        this.id_Pengangkutan.set(id_Pengangkutan);
    }

    public String getHari_Operasional() {
        return hari_Operasional.get();
    }

    public StringProperty hari_OperasionalProperty() {
        return hari_Operasional;
    }

    public void setHari_Operasional(String hari_Operasional) {
        this.hari_Operasional.set(hari_Operasional);
    }

    public String getJam_Operasional() {
        return jam_Operasional.get();
    }

    public StringProperty jam_OperasionalProperty() {
        return jam_Operasional;
    }

    public void setJam_Operasional(String jam_Operasional) {
        this.jam_Operasional.set(jam_Operasional);
    }

    public String getJenis_Truk() {
        return jenis_Truk.get();
    }

    public StringProperty jenis_TrukProperty() {
        return jenis_Truk;
    }

    public void setJenis_Truk(String jenis_Truk) {
        this.jenis_Truk.set(jenis_Truk);
    }
}

class rekap {

    private StringProperty allPropertiDijual;
    private StringProperty allPropertiBelumDijual;
    private StringProperty allPropertiSudahDijual;
    private StringProperty allFasilitasTersedia;
    private StringProperty allKomunitasTersedia;
    private StringProperty allCSTersedia;

    public rekap() {
        this.allPropertiDijual = new SimpleStringProperty();
        this.allPropertiBelumDijual = new SimpleStringProperty();
        this.allPropertiSudahDijual = new SimpleStringProperty();
        this.allFasilitasTersedia = new SimpleStringProperty();
        this.allKomunitasTersedia = new SimpleStringProperty();
        this.allCSTersedia = new SimpleStringProperty();
    }

    public String getAllPropertiDijual() {
        return allPropertiDijual.get();
    }

    public StringProperty allPropertiDijualProperty() {
        return allPropertiDijual;
    }

    public String getAllPropertiBelumDijual() {
        return allPropertiBelumDijual.get();
    }

    public StringProperty allPropertiBelumDijualProperty() {
        return allPropertiBelumDijual;
    }

    public String getAllPropertiSudahDijual() {
        return allPropertiSudahDijual.get();
    }

    public StringProperty allPropertiSudahDijualProperty() {
        return allPropertiSudahDijual;
    }

    public String getAllFasilitasTersedia() {
        return allFasilitasTersedia.get();
    }

    public StringProperty allFasilitasTersediaProperty() {
        return allFasilitasTersedia;
    }

    public String getAllKomunitasTersedia() {
        return allKomunitasTersedia.get();
    }

    public StringProperty allKomunitasTersediaProperty() {
        return allKomunitasTersedia;
    }

    public String getAllCSTersedia() {
        return allCSTersedia.get();
    }

    public StringProperty allCSTersediaProperty() {
        return allCSTersedia;
    }
    public void setAllPropertiDijual(String allPropertiDijual) {
        this.allPropertiDijual.set(allPropertiDijual);
    }

    public void setAllPropertiBelumDijual(String allPropertiBelumDijual) {
        this.allPropertiBelumDijual.set(allPropertiBelumDijual);
    }

    public void setAllPropertiSudahDijual(String allPropertiSudahDijual) {
        this.allPropertiSudahDijual.set(allPropertiSudahDijual);
    }

    public void setAllFasilitasTersedia(String allFasilitasTersedia) {
        this.allFasilitasTersedia.set(allFasilitasTersedia);
    }

    public void setAllKomunitasTersedia(String allKomunitasTersedia) {
        this.allKomunitasTersedia.set(allKomunitasTersedia);
    }

    public void setAllCSTersedia(String allCSTersedia) {
        this.allCSTersedia.set(allCSTersedia);
    }
}


public class AdminDashboard extends Application {

    private String username;
    private Text RekapText;

    public void setUsername(String username) {
        this.username = username;
    }

    Circle lingkaranActive;
    TextField username123;
    Rectangle navigasi;
    HBox all;
    ScrollPane scrollPane;
    ImageView logo;
    ImageView logout;
    ImageView iconDashboard;
    ImageView iconManajemenPr;
    ImageView iconManajemenFs;
    ImageView iconManajemenKb;
    ImageView iconManajemenKm;
    GridPane navGridPane;
    StackPane contentkanan;
    StackPane navigasikiri;
    Text dashBoardtxt;
    Line garisdashBoardtxt;
    Text arayaLand;
    Circle lingkaran1;
    Circle lingkaran2;
    Circle lingkaran3;
    Circle lingkaran4;

    private static final String[] IMAGE_ARAYA = {
            "/com/example/arayalandbasdat/image/araya1.png",
            "/com/example/arayalandbasdat/image/araya2.png",
            "/com/example/arayalandbasdat/image/araya3.png",
            "/com/example/arayalandbasdat/image/araya4.png"
    };

    ImageView boardAraya;

    int current_image = 0;

    HBox circle;

    GridPane detailAraya;

    HBox instagram;
    HBox notelfon;
    HBox lokasi;

    ImageView ig;
    ImageView no;
    ImageView lok;
    Button namaig;
    Button alamatlokasi;
    Button nomoraraya;
    Text texttotalDIJUAL;
    TextField totalPropertiDIJUAL;
    Text texttotalBELUMTERJUAL;
    TextField totalPropertiBELUMTERJUAL;
    Text texttotalSUDAHTERJUAL;
    TextField totalPropertiSUDAHTERJUAL;
    Text texttotalFASILITAS;
    TextField totalFASILITAS;
    Text texttotalKOMUNITAS;
    TextField totalKOMUNITAS;
    Text texttotalCS;
    TextField totalCS;
    Button hapus;
    ImageView excel1;


    private HostServices hostServices;

    @Override
    public void init() throws Exception {
        super.init();
        hostServices = getHostServices();
    }

    private TableView<TotalPropertiYangDijual> tableTotalPropertiYangDijual;
    private TableView<TotalPropertiBelumTerjual> tableTotalPropertiBelumTerjual;
    private TableView<TotalPropertiSudahTerjual> tableTotalPropertiSudahTerjual;
    private TableView<AllFasilitas> tableAllFasilitas;
    private TableView<AllKomunitas> tableAllKomunitas;
    private TableView<AllLayananKebersihan> tableAllLayananKebersihan;
    private TableView<rekap> tableRekap;

    private static int fileCounter = 0;

    private static final String DB_URL = "jdbc:oracle:thin:@//localhost:1521/xe"; // Sesuaikan dengan URL database Anda
    private static final String DB_USER = "SYSTEM"; // Ganti dengan username database Anda
    private static final String DB_PASSWORD = "SYSTEM";

    @Override
    public void start(Stage stage) throws Exception {

        //navigasi kiri

        logo = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/logo.png")));
        logo.setFitWidth(200);
        logo.setFitHeight(200);
        logo.setTranslateX(-10);
        logo.setTranslateY(-2420);

        logo.setBlendMode(BlendMode.ADD);


        Timeline timelineLogo = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(logo.opacityProperty(), 0.2)),
                new KeyFrame(Duration.seconds(2), new KeyValue(logo.opacityProperty(), 1.0)),
                new KeyFrame(Duration.seconds(4), new KeyValue(logo.opacityProperty(), 0.2))
        );
        timelineLogo.setCycleCount(Animation.INDEFINITE);
        timelineLogo.play();

        Glow glow = new Glow(0.8);
        logo.setEffect(glow);

        iconDashboard = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Dashboard.png")));
        iconDashboard.setFitWidth(90);
        iconDashboard.setFitHeight(90);
        iconDashboard.setOnMouseEntered(event -> iconDashboard.setCursor(Cursor.HAND));
        iconDashboard.setOnMouseExited(event -> iconDashboard.setCursor(Cursor.DEFAULT));

        iconManajemenPr = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Manajemen_Properti.png")));
        iconManajemenPr.setFitWidth(100);
        iconManajemenPr.setFitHeight(100);
        iconManajemenPr.setOnMouseEntered(event -> iconManajemenPr.setCursor(Cursor.HAND));
        iconManajemenPr.setOnMouseExited(event -> iconManajemenPr.setCursor(Cursor.DEFAULT));

        iconManajemenFs = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Manajemen_Fasilitas.png")));
        iconManajemenFs.setFitWidth(100);
        iconManajemenFs.setFitHeight(100);
        iconManajemenFs.setOnMouseEntered(event -> iconManajemenFs.setCursor(Cursor.HAND));
        iconManajemenFs.setOnMouseExited(event -> iconManajemenFs.setCursor(Cursor.DEFAULT));

        iconManajemenKm = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Manajemen_Komunitas.png")));
        iconManajemenKm.setFitWidth(100);
        iconManajemenKm.setFitHeight(100);
        iconManajemenKm.setOnMouseEntered(event -> iconManajemenKm.setCursor(Cursor.HAND));
        iconManajemenKm.setOnMouseExited(event -> iconManajemenKm.setCursor(Cursor.DEFAULT));

        iconManajemenKb = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Manajemen_Kebersihan.png")));
        iconManajemenKb.setFitWidth(100);
        iconManajemenKb.setFitHeight(100);
        iconManajemenKb.setOnMouseEntered(event -> iconManajemenKb.setCursor(Cursor.HAND));
        iconManajemenKb.setOnMouseExited(event -> iconManajemenKb.setCursor(Cursor.DEFAULT));

        logout = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/logout.png")));
        logout.setFitWidth(100);
        logout.setFitHeight(100);
        logout.setTranslateY(2450);
        logout.setOnMouseEntered(event -> logout.setCursor(Cursor.HAND));
        logout.setOnMouseExited(event -> logout.setCursor(Cursor.DEFAULT));

        navGridPane = new GridPane();
        navGridPane.setVgap(40);
        navGridPane.add(iconDashboard, 0, 1);
        navGridPane.add(iconManajemenPr, 0, 2);
        navGridPane.add(iconManajemenFs, 0, 3);
        navGridPane.add(iconManajemenKm, 0, 4);
        navGridPane.add(iconManajemenKb, 0, 5);
        navGridPane.setAlignment(Pos.CENTER);
        navGridPane.setTranslateX(0);
        navGridPane.setTranslateY(-2020);

        navigasi = new Rectangle(250, 5000, Color.web("#316d18"));


        //content kanan

        dashBoardtxt = new Text("Dashboard");
        dashBoardtxt.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 40px; "
                + "-fx-fill: #545454; -fx-font-weight: bold");
        dashBoardtxt.setTranslateX(-480);
        dashBoardtxt.setTranslateY(-2430);

        garisdashBoardtxt = new Line();
        garisdashBoardtxt.setStartX(270);  // Koordinat awal garis
        garisdashBoardtxt.setEndX(1535);    // Koordinat akhir garis (sesuaikan panjang sesuai kebutuhan)
        garisdashBoardtxt.setTranslateY(-2380);  // Sesuaikan posisi vertikal
        garisdashBoardtxt.setStroke(Color.web("#a6a6a6"));  // Warna garis
        garisdashBoardtxt.setStrokeWidth(5);  // Ketebalan garis
        garisdashBoardtxt.setTranslateX(0);

        lingkaranActive = new Circle(10, Color.LIMEGREEN);
        lingkaranActive.setTranslateY(-2410);
        lingkaranActive.setTranslateX(450);


        username123 = new TextField(username);
        username123.setStyle("-fx-font-family: 'Montserrat'; -fx-background-color: #a6a6a6;"
                + "-fx-font-size: 17px;-fx-font-weight: bold; "
                + "-fx-prompt-text-fill: white; -fx-text-fill: white;"
                + "-fx-background-radius: 30; "
                + "-fx-border-radius: 30;"
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; ");
        username123.setMaxWidth(200);
        username123.setTranslateX(530);
        username123.setTranslateY(-2410);
        username123.setEditable(false);
        username123.setAlignment(Pos.CENTER);

        arayaLand = new Text("ArayaLand");
        arayaLand.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 40px; "
                + "-fx-fill: #545454; -fx-font-weight: bold");
        arayaLand.setTranslateY(-2330);
        arayaLand.setTextAlignment(TextAlignment.CENTER);

        boardAraya = new ImageView(new Image(getClass().getResourceAsStream(IMAGE_ARAYA[current_image])));
        boardAraya.setFitWidth(1200);
        boardAraya.setFitHeight(420);
        boardAraya.setTranslateY(-2070);
        boardAraya.setTranslateX(0);


        Timeline timelineBoard = new Timeline(
                new KeyFrame(Duration.seconds(2), event -> showNextImage())
        );
        timelineBoard.setCycleCount(Timeline.INDEFINITE);
        timelineBoard.play();

        lingkaran1 = new Circle(10, Color.LIGHTGRAY);
        lingkaran2 = new Circle(10, Color.LIGHTGRAY);
        lingkaran3 = new Circle(10, Color.LIGHTGRAY);
        lingkaran4 = new Circle(10, Color.LIGHTGRAY);

        circle = new HBox(30);
        circle.getChildren().addAll(lingkaran1, lingkaran2, lingkaran3, lingkaran4);
        circle.setAlignment(Pos.CENTER);
        circle.setTranslateY(-1820);

        PauseTransition pause1 = new PauseTransition(Duration.seconds(2));
        PauseTransition pause2 = new PauseTransition(Duration.seconds(2));
        PauseTransition pause3 = new PauseTransition(Duration.seconds(2));
        PauseTransition pause4 = new PauseTransition(Duration.seconds(2));
        pause1.setOnFinished(event -> {
            lingkaran1.setFill(Color.LIGHTGRAY);
            lingkaran2.setFill(Color.YELLOW);
            lingkaran3.setFill(Color.LIGHTGRAY);
            lingkaran4.setFill(Color.LIGHTGRAY);
            pause2.play();
        });
        pause2.setOnFinished(event -> {
            lingkaran1.setFill(Color.LIGHTGRAY);
            lingkaran2.setFill(Color.LIGHTGRAY);
            lingkaran3.setFill(Color.YELLOW);
            lingkaran4.setFill(Color.LIGHTGRAY);
            pause3.play();
        });
        pause3.setOnFinished(event -> {
            lingkaran1.setFill(Color.LIGHTGRAY);
            lingkaran2.setFill(Color.LIGHTGRAY);
            lingkaran3.setFill(Color.LIGHTGRAY);
            lingkaran4.setFill(Color.YELLOW);
            pause4.play();
        });
        pause4.setOnFinished(event -> {
            lingkaran1.setFill(Color.YELLOW);
            lingkaran2.setFill(Color.LIGHTGRAY);
            lingkaran3.setFill(Color.LIGHTGRAY);
            lingkaran4.setFill(Color.LIGHTGRAY);
            pause1.play();
        });
        lingkaran1.setFill(Color.YELLOW);
        lingkaran2.setFill(Color.LIGHTGRAY);
        lingkaran3.setFill(Color.LIGHTGRAY);
        lingkaran4.setFill(Color.LIGHTGRAY);
        pause1.play();

        lok = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Lokasi.png")));
        lok.setFitWidth(50);
        lok.setFitHeight(50);
        lok.setOnMouseEntered(event -> lok.setCursor(Cursor.HAND));
        lok.setOnMouseExited(event -> lok.setCursor(Cursor.DEFAULT));


        ig = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Instagram.png")));
        ig.setFitWidth(50);
        ig.setFitHeight(50);
        ig.setOnMouseEntered(event -> ig.setCursor(Cursor.HAND));
        ig.setOnMouseExited(event -> ig.setCursor(Cursor.DEFAULT));


        no = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/Whatsapp.png")));
        no.setFitWidth(50);
        no.setFitHeight(50);
        no.setOnMouseEntered(event -> no.setCursor(Cursor.HAND));
        no.setOnMouseExited(event -> no.setCursor(Cursor.DEFAULT));

        alamatlokasi = new Button("Jl. Telaga Golf Utama No.24,\n" +
                "Kabupaten Malang, Jawa Timur ");
        alamatlokasi.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 21px; "
                + "-fx-fill: #545454; -fx-background-color: transparent; -fx-border-color: transparent;");
        alamatlokasi.setOnMouseEntered(event -> alamatlokasi.setCursor(Cursor.HAND));
        alamatlokasi.setOnMouseExited(event -> alamatlokasi.setCursor(Cursor.DEFAULT));

        namaig = new Button("@ArayaLand_mlg");
        namaig.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 21px; "
                + "-fx-fill: #545454; -fx-background-color: transparent; -fx-border-color: transparent;");
        namaig.setOnMouseEntered(event -> namaig.setCursor(Cursor.HAND));
        namaig.setOnMouseExited(event -> namaig.setCursor(Cursor.DEFAULT));

        nomoraraya = new Button("+62 851 - 0013 - 143");
        nomoraraya.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 21px; "
                + "-fx-fill: #545454; -fx-background-color: transparent; -fx-border-color: transparent;");
        nomoraraya.setOnMouseEntered(event -> nomoraraya.setCursor(Cursor.HAND));
        nomoraraya.setOnMouseExited(event -> nomoraraya.setCursor(Cursor.DEFAULT));

        lokasi = new HBox(10);
        lokasi.getChildren().addAll(lok, alamatlokasi);
        instagram = new HBox(10);
        instagram.getChildren().addAll(ig, namaig);
        notelfon = new HBox(10);
        notelfon.getChildren().addAll(no, nomoraraya);

        detailAraya = new GridPane();
        detailAraya.setVgap(50);
        detailAraya.add(lokasi, 0, 0);
        detailAraya.add(instagram, 0, 1);
        detailAraya.add(notelfon, 0, 2);
        detailAraya.setTranslateY(710);
        detailAraya.setTranslateX(50);


        //table 1

        tableTotalPropertiYangDijual = new TableView<>();

        tableTotalPropertiYangDijual = new TableView<>();

        TableColumn<TotalPropertiYangDijual, String> nomorProperti = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti.setCellValueFactory(cellData -> cellData.getValue().nomorPropertiProperty());
        nomorProperti.setPrefWidth(120);

        TableColumn<TotalPropertiYangDijual, String> namaProperti = new TableColumn<>("NAMA PROPERTI");
        namaProperti.setCellValueFactory(cellData -> cellData.getValue().namaPropertiProperty());
        namaProperti.setPrefWidth(120);

        TableColumn<TotalPropertiYangDijual, String> areaProperti = new TableColumn<>("AREA");
        areaProperti.setCellValueFactory(cellData -> cellData.getValue().areaPropertiProperty());
        areaProperti.setPrefWidth(120);

        TableColumn<TotalPropertiYangDijual, Number> luasTanahProperti = new TableColumn<>("LUAS TANAH");
        luasTanahProperti.setCellValueFactory(cellData -> cellData.getValue().luasTanahPropertiProperty());
        luasTanahProperti.setPrefWidth(120);


        TableColumn<TotalPropertiYangDijual, Number> hargaTanahProperti = new TableColumn<>("HARGA TANAH");
        hargaTanahProperti.setCellValueFactory(cellData -> cellData.getValue().hargaTanahPropertiProperty());
        hargaTanahProperti.setPrefWidth(120);
        hargaTanahProperti.setCellFactory(tc -> new TableCell<TotalPropertiYangDijual, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDijual, Number> luasBangunanProperti = new TableColumn<>("LUAS BANGUNAN");
        luasBangunanProperti.setCellValueFactory(cellData -> cellData.getValue().luasBangunanPropertiProperty());
        luasBangunanProperti.setPrefWidth(150);

        TableColumn<TotalPropertiYangDijual, Number> hargaBangunanProperti = new TableColumn<>("HARGA BANGUNAN");
        hargaBangunanProperti.setCellValueFactory(cellData -> cellData.getValue().hargaBangunanPropertiProperty());
        hargaBangunanProperti.setPrefWidth(150);
        hargaBangunanProperti.setCellFactory(tc -> new TableCell<TotalPropertiYangDijual, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDijual, Number> ppnProperti = new TableColumn<>("PPN 10%");
        ppnProperti.setCellValueFactory(cellData -> cellData.getValue().ppnPropertiProperty());
        ppnProperti.setPrefWidth(120);
        ppnProperti.setCellFactory(tc -> new TableCell<TotalPropertiYangDijual, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        TableColumn<TotalPropertiYangDijual, Number> hargaTotalProperti = new TableColumn<>("HARGA TOTAL");
        hargaTotalProperti.setCellValueFactory(cellData -> cellData.getValue().hargaTotalPropertiProperty());
        hargaTotalProperti.setPrefWidth(183);
        hargaTotalProperti.setCellFactory(tc -> new TableCell<TotalPropertiYangDijual, Number>() {
            @Override
            protected void updateItem(Number item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setText(null);
                } else {
                    setText(String.format("%,.0f", item.doubleValue()));
                }
            }
        });

        tableTotalPropertiYangDijual.getColumns().addAll(nomorProperti, namaProperti, areaProperti,
                luasTanahProperti, hargaTanahProperti, luasBangunanProperti, hargaBangunanProperti,
                ppnProperti, hargaTotalProperti);
        tableTotalPropertiYangDijual.setTranslateY(-1200);
        tableTotalPropertiYangDijual.setMaxWidth(1200);
        tableTotalPropertiYangDijual.setMaxHeight(420);
        tableTotalPropertiYangDijual.setEditable(false);

        Rectangle cardDownlaod = new Rectangle(300, 300, Color.web("#DDDDDD"));
        cardDownlaod.setArcWidth(50); // Set lebar sudut
        cardDownlaod.setArcHeight(50); // Set tinggi sudut
        cardDownlaod.setTranslateX(410);
        cardDownlaod.setTranslateY(-1640);


        Text downloadExcel = new Text("Download Laporan Excel" +
                "\nDisini ⬇");
        downloadExcel.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        downloadExcel.setFill(Color.GREEN);
        downloadExcel.setTextAlignment(TextAlignment.CENTER);
        downloadExcel.setTranslateX(410);
        downloadExcel.setTranslateY(-1740);


        excel1 = new ImageView(new Image(getClass().getResourceAsStream("/com/example/arayalandbasdat/image/EXCEL1.png")));
        excel1.setFitWidth(170);
        excel1.setFitHeight(170);
        excel1.setTranslateX(410);
        excel1.setTranslateY(-1600);

        texttotalDIJUAL = new Text("TOTAL PROPERTI : " +
                "\n (YANG DIJUAL)");
        texttotalDIJUAL.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalDIJUAL.setTranslateX(-500);
        texttotalDIJUAL.setTranslateY(-900);

        totalPropertiDIJUAL = new TextField();
        totalPropertiDIJUAL.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalPropertiDIJUAL.setTranslateX(-300);
        totalPropertiDIJUAL.setTranslateY(-900);
        totalPropertiDIJUAL.setMaxWidth(100);
        totalPropertiDIJUAL.setEditable(false);
        totalPropertiDIJUAL.setAlignment(Pos.CENTER);
        totalPropertiDIJUAL.textProperty().bind(Bindings.size(tableTotalPropertiYangDijual.getItems()).asString());


        //tabel 2
        tableTotalPropertiBelumTerjual = new TableView<>();

        TableColumn<TotalPropertiBelumTerjual, String> nomorProperti2 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti2.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti2.setPrefWidth(270);

        TableColumn<TotalPropertiBelumTerjual, String> namaProperti2 = new TableColumn<>("NAMA PROPERTI");
        namaProperti2.setCellValueFactory(cellData -> cellData.getValue().nama_PropertiProperty());
        namaProperti2.setPrefWidth(270);

        TableColumn<TotalPropertiBelumTerjual, String> areaProperti2 = new TableColumn<>("AREA");
        areaProperti2.setCellValueFactory(cellData -> cellData.getValue().area_PropertiProperty());
        areaProperti2.setPrefWidth(170);

        TableColumn<TotalPropertiBelumTerjual, Number> luasTanahProperti2 = new TableColumn<>("LUAS TANAH");
        luasTanahProperti2.setCellValueFactory(cellData -> cellData.getValue().luas_Tanah_PropertiProperty());
        luasTanahProperti2.setPrefWidth(270);

        TableColumn<TotalPropertiBelumTerjual, Number> luasBangunanProperti2 = new TableColumn<>("LUAS BANGUNAN");
        luasBangunanProperti2.setCellValueFactory(cellData -> cellData.getValue().luas_Bangunan_PropertiProperty());
        luasBangunanProperti2.setPrefWidth(270);

        tableTotalPropertiBelumTerjual.getColumns().addAll(
                nomorProperti2,
                namaProperti2,
                areaProperti2,
                luasTanahProperti2,
                luasBangunanProperti2
        );

        tableTotalPropertiBelumTerjual.setTranslateY(-600);
        tableTotalPropertiBelumTerjual.setMaxWidth(1200);
        tableTotalPropertiBelumTerjual.setMaxHeight(420);
        tableTotalPropertiBelumTerjual.setEditable(false);


        hapus = new Button("HAPUS");
        hapus.setStyle("-fx-background-color: #ff2121; -fx-font-size: 17px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        hapus.setTranslateX(0);
        hapus.setTranslateY(-370);
        hapus.setMaxWidth(150);


        texttotalBELUMTERJUAL = new Text("TOTAL PROPERTI : " +
                "\n (YANG BELUM TERJUAL)");
        texttotalBELUMTERJUAL.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalBELUMTERJUAL.setTranslateX(-480);
        texttotalBELUMTERJUAL.setTranslateY(-300);
        texttotalBELUMTERJUAL.setTextAlignment(TextAlignment.CENTER);

        totalPropertiBELUMTERJUAL = new TextField();
        totalPropertiBELUMTERJUAL.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalPropertiBELUMTERJUAL.setTranslateX(-300);
        totalPropertiBELUMTERJUAL.setTranslateY(-300);
        totalPropertiBELUMTERJUAL.setMaxWidth(100);
        totalPropertiBELUMTERJUAL.setEditable(false);
        totalPropertiBELUMTERJUAL.setAlignment(Pos.CENTER);
        totalPropertiBELUMTERJUAL.textProperty().bind(Bindings.size(tableTotalPropertiBelumTerjual.getItems()).asString());


        //tabel 3
        tableTotalPropertiSudahTerjual = new TableView<>();

        TableColumn<TotalPropertiSudahTerjual, String> usernameProperti3 = new TableColumn<>("USERNAME");
        usernameProperti3.setCellValueFactory(cellData -> cellData.getValue().username_PropertiProperty());
        usernameProperti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, String> idTransaksi3 = new TableColumn<>("ID TRANSAKSI");
        idTransaksi3.setCellValueFactory(cellData -> cellData.getValue().ID_TransaksiProperty());
        idTransaksi3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, String> nomorProperti3 = new TableColumn<>("NOMOR PROPERTI");
        nomorProperti3.setCellValueFactory(cellData -> cellData.getValue().nomor_PropertiProperty());
        nomorProperti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, String> nama_Properti3 = new TableColumn<>("NAMA PROPERTI");
        nama_Properti3.setCellValueFactory(cellData -> cellData.getValue().nama_PropertiProperty());
        nama_Properti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, String> area_Properti3 = new TableColumn<>("AREA");
        area_Properti3.setCellValueFactory(cellData -> cellData.getValue().area_PropertiProperty());
        area_Properti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, Number> luasTanahProperti3 = new TableColumn<>("LUAS TANAH");
        luasTanahProperti3.setCellValueFactory(cellData -> cellData.getValue().luas_Tanah_PropertiProperty());
        luasTanahProperti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, Number> luasBangunanProperti3 = new TableColumn<>("LUAS BANGUNAN");
        luasBangunanProperti3.setCellValueFactory(cellData -> cellData.getValue().luas_Bangunan_PropertiProperty());
        luasBangunanProperti3.setPrefWidth(150);

        TableColumn<TotalPropertiSudahTerjual, String> statusProperti3 = new TableColumn<>("STATUS PROPERTI");
        statusProperti3.setCellValueFactory(cellData -> cellData.getValue().status_PropertiProperty());
        statusProperti3.setPrefWidth(150);

        tableTotalPropertiSudahTerjual.getColumns().addAll(
                usernameProperti3,
                idTransaksi3,
                nomorProperti3,
                nama_Properti3,
                area_Properti3,
                luasTanahProperti3,
                luasBangunanProperti3,
                statusProperti3
        );

        tableTotalPropertiSudahTerjual.setTranslateY(0);
        tableTotalPropertiSudahTerjual.setMaxWidth(1200);
        tableTotalPropertiSudahTerjual.setMaxHeight(420);
        tableTotalPropertiSudahTerjual.setEditable(false);


        texttotalSUDAHTERJUAL = new Text("TOTAL PROPERTI : " +
                "\n (YANG SUDAH TERJUAL)");
        texttotalSUDAHTERJUAL.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalSUDAHTERJUAL.setTranslateX(-480);
        texttotalSUDAHTERJUAL.setTranslateY(290);
        texttotalSUDAHTERJUAL.setTextAlignment(TextAlignment.CENTER);

        totalPropertiSUDAHTERJUAL = new TextField();
        totalPropertiSUDAHTERJUAL.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalPropertiSUDAHTERJUAL.setTranslateX(-300);
        totalPropertiSUDAHTERJUAL.setTranslateY(290);
        totalPropertiSUDAHTERJUAL.setMaxWidth(100);
        totalPropertiSUDAHTERJUAL.setEditable(false);
        totalPropertiSUDAHTERJUAL.setAlignment(Pos.CENTER);
        totalPropertiSUDAHTERJUAL.textProperty().bind(Bindings.size(tableTotalPropertiSudahTerjual.getItems()).asString());


        //tabel4
        tableAllFasilitas = new TableView<>();

        TableColumn<AllFasilitas, String> namaFasilitas4 = new TableColumn<>("NAMA FASILITAS");
        namaFasilitas4.setCellValueFactory(cellData -> cellData.getValue().nama_FasilitasProperty());
        namaFasilitas4.setPrefWidth(240);

        TableColumn<AllFasilitas, String> hariOperasional4 = new TableColumn<>("HARI OPERASIONAL");
        hariOperasional4.setCellValueFactory(cellData -> cellData.getValue().hari_OperasionalProperty());
        hariOperasional4.setPrefWidth(240);

        TableColumn<AllFasilitas, String> jamOperasional4 = new TableColumn<>("JAM OPERASIONAL");
        jamOperasional4.setCellValueFactory(cellData -> cellData.getValue().jam_OperasionalProperty());
        jamOperasional4.setPrefWidth(240);

        TableColumn<AllFasilitas, Number> kapasitas4 = new TableColumn<>("KAPASITAS");
        kapasitas4.setCellValueFactory(cellData -> cellData.getValue().kapasitasProperty());
        kapasitas4.setPrefWidth(240);

        TableColumn<AllFasilitas, Number> rating4 = new TableColumn<>("RATING");
        rating4.setCellValueFactory(cellData -> cellData.getValue().ratingProperty());
        rating4.setPrefWidth(240);

        tableAllFasilitas.getColumns().addAll(
                namaFasilitas4,
                hariOperasional4,
                jamOperasional4,
                kapasitas4,
                rating4
        );

        tableAllFasilitas.setTranslateY(580);
        tableAllFasilitas.setMaxWidth(1200);
        tableAllFasilitas.setMaxHeight(420);
        tableAllFasilitas.setEditable(false);


        texttotalFASILITAS = new Text("TOTAL FASILITAS : ");
        texttotalFASILITAS.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalFASILITAS.setTranslateX(-480);
        texttotalFASILITAS.setTranslateY(890);
        texttotalFASILITAS.setTextAlignment(TextAlignment.CENTER);

        totalFASILITAS = new TextField();
        totalFASILITAS.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalFASILITAS.setTranslateX(-300);
        totalFASILITAS.setTranslateY(890);
        totalFASILITAS.setMaxWidth(100);
        totalFASILITAS.setEditable(false);
        totalFASILITAS.setAlignment(Pos.CENTER);
        totalFASILITAS.textProperty().bind(Bindings.size(tableAllFasilitas.getItems()).asString());


        //tabel 5
        tableAllKomunitas = new TableView<>();

        TableColumn<AllKomunitas, String> namaKomunitas5 = new TableColumn<>("NAMA KOMUNITAS");
        namaKomunitas5.setCellValueFactory(cellData -> cellData.getValue().nama_KomunitasProperty());
        namaKomunitas5.setPrefWidth(300);

        TableColumn<AllKomunitas, String> tanggalPdrn5 = new TableColumn<>("TANGGAL PENDIRIAN");
        tanggalPdrn5.setCellValueFactory(cellData -> cellData.getValue().tanggal_PendirianProperty());
        tanggalPdrn5.setPrefWidth(300);
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        tanggalPdrn5.setCellValueFactory(cellData -> {
            SimpleStringProperty property = new SimpleStringProperty();
            String tanggalString = cellData.getValue().getTanggal_Pendirian(); // Ganti ini dengan method yang sesuai

            try {
                LocalDateTime dateTime = LocalDateTime.parse(tanggalString, dateTimeFormatter);
                String formattedTanggal = dateTime.toLocalDate().toString();
                property.set(formattedTanggal);
            } catch (Exception e) {
                e.printStackTrace();
                property.set("Invalid Date");
            }

            return property;
        });

        TableColumn<AllKomunitas, String> agendaKomunitas5 = new TableColumn<>("AGENDA");
        agendaKomunitas5.setCellValueFactory(cellData -> cellData.getValue().agenda_KomunitasProperty());
        agendaKomunitas5.setPrefWidth(300);

        TableColumn<AllKomunitas, String> syaratKomunitas5 = new TableColumn<>("SYARAT");
        syaratKomunitas5.setCellValueFactory(cellData -> cellData.getValue().syarat_KomunitasProperty());
        syaratKomunitas5.setPrefWidth(300);

        tableAllKomunitas.getColumns().addAll(
                namaKomunitas5,
                tanggalPdrn5,
                agendaKomunitas5,
                syaratKomunitas5
        );

        tableAllKomunitas.setTranslateY(1180);
        tableAllKomunitas.setMaxWidth(1200);
        tableAllKomunitas.setMaxHeight(420);
        tableAllKomunitas.setEditable(false);


        texttotalKOMUNITAS = new Text("TOTAL KOMUNITAS : ");
        texttotalKOMUNITAS.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalKOMUNITAS.setTranslateX(-480);
        texttotalKOMUNITAS.setTranslateY(1480);
        texttotalKOMUNITAS.setTextAlignment(TextAlignment.CENTER);

        totalKOMUNITAS = new TextField();
        totalKOMUNITAS.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalKOMUNITAS.setTranslateX(-300);
        totalKOMUNITAS.setTranslateY(1480);
        totalKOMUNITAS.setMaxWidth(100);
        totalKOMUNITAS.setEditable(false);
        totalKOMUNITAS.setAlignment(Pos.CENTER);
        totalKOMUNITAS.textProperty().bind(Bindings.size(tableAllKomunitas.getItems()).asString());


        //tabel 6
        tableAllLayananKebersihan = new TableView<>();

        TableColumn<AllLayananKebersihan, String> idPengangkutan6 = new TableColumn<>("ID PENGANGKUTAN");
        idPengangkutan6.setCellValueFactory(cellData -> cellData.getValue().id_PengangkutanProperty());
        idPengangkutan6.setPrefWidth(300);

        TableColumn<AllLayananKebersihan, String> hariOperasional6 = new TableColumn<>("HARI OPERASIONAL");
        hariOperasional6.setCellValueFactory(cellData -> cellData.getValue().hari_OperasionalProperty());
        hariOperasional6.setPrefWidth(300);

        TableColumn<AllLayananKebersihan, String> jamOperasional6 = new TableColumn<>("JAM OPERASIONAL");
        jamOperasional6.setCellValueFactory(cellData -> cellData.getValue().jam_OperasionalProperty());
        jamOperasional6.setPrefWidth(300);

        TableColumn<AllLayananKebersihan, String> jenisTruk6 = new TableColumn<>("JENIS TRUK");
        jenisTruk6.setCellValueFactory(cellData -> cellData.getValue().jenis_TrukProperty());
        jenisTruk6.setPrefWidth(300);

        tableAllLayananKebersihan.getColumns().addAll(
                idPengangkutan6,
                hariOperasional6,
                jamOperasional6,
                jenisTruk6
        );

        tableAllLayananKebersihan.setTranslateY(1780);
        tableAllLayananKebersihan.setMaxWidth(1200);
        tableAllLayananKebersihan.setMaxHeight(420);
        tableAllLayananKebersihan.setEditable(false);


        texttotalCS = new Text("TOTAL LAYANAN KEBERSIHAN : " +
                "\n(ANGKUT SAMPAH)");
        texttotalCS.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 20px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        texttotalCS.setTranslateX(-450);
        texttotalCS.setTranslateY(2080);
        texttotalCS.setTextAlignment(TextAlignment.CENTER);

        totalCS = new TextField();
        totalCS.setStyle("-fx-background-color: #316d18; -fx-font-size: 26px; "
                + "-fx-text-fill: white; "
                + "-fx-background-radius: 50; "
                + "-fx-border-radius: 50; "
                + "-fx-focus-color: transparent; "
                + "-fx-faint-focus-color: transparent; "
                + "-fx-highlight-fill: transparent; "
                + "-fx-highlight-text-fill: white;");
        totalCS.setTranslateX(-150);
        totalCS.setTranslateY(2080);
        totalCS.setMaxWidth(100);
        totalCS.setEditable(false);
        totalCS.setAlignment(Pos.CENTER);
        totalCS.textProperty().bind(Bindings.size(tableAllLayananKebersihan.getItems()).asString());


        //tabel Rekapan

        RekapText = new Text("REKAP");
        RekapText.setStyle("-fx-font-family: 'Montserrat'; "
                + "-fx-font-size: 36px; "
                + "-fx-fill: #3D3A3B; -fx-font-weight: bold");
        RekapText.setTranslateX(0);
        RekapText.setTranslateY(2300);
        RekapText.setTextAlignment(TextAlignment.CENTER);


        tableRekap = new TableView<>();

        // Buat TableColumn dengan Callback lambda untuk setiap properti
        TableColumn<rekap, String> totalPropertiDijual = new TableColumn<>("PROPERTI DIJUAL");
        totalPropertiDijual.setCellValueFactory(cellData -> cellData.getValue().allPropertiDijualProperty());
        totalPropertiDijual.setPrefWidth(200);

        TableColumn<rekap, String> totalPropertiBelum = new TableColumn<>("PROPERTI BELUM TERJUAL");
        totalPropertiBelum.setCellValueFactory(cellData -> cellData.getValue().allPropertiBelumDijualProperty());
        totalPropertiBelum.setPrefWidth(200);

        TableColumn<rekap, String> totalPropertiSudahDijual = new TableColumn<>("PROPERTI TERJUAL");
        totalPropertiSudahDijual.setCellValueFactory(cellData -> cellData.getValue().allPropertiSudahDijualProperty());
        totalPropertiSudahDijual.setPrefWidth(200);

        TableColumn<rekap, String> totalFasilitasTersedia = new TableColumn<>("TOTAL FASILITAS");
        totalFasilitasTersedia.setCellValueFactory(cellData -> cellData.getValue().allFasilitasTersediaProperty());
        totalFasilitasTersedia.setPrefWidth(200);

        TableColumn<rekap, String> totalKomunitasTersedia = new TableColumn<>("TOTAL KOMUNITAS");
        totalKomunitasTersedia.setCellValueFactory(cellData -> cellData.getValue().allKomunitasTersediaProperty());
        totalKomunitasTersedia.setPrefWidth(200);

        TableColumn<rekap, String> totalCSTersedia = new TableColumn<>("TOTAL KEBERSIHAN");
        totalCSTersedia.setCellValueFactory(cellData -> cellData.getValue().allCSTersediaProperty());
        totalCSTersedia.setPrefWidth(200);


        tableRekap.getColumns().addAll(totalPropertiDijual, totalPropertiBelum, totalPropertiSudahDijual, totalFasilitasTersedia, totalKomunitasTersedia, totalCSTersedia
        );
        tableRekap.setTranslateY(2400);
        tableRekap.setMaxWidth(1200);
        tableRekap.setMaxHeight(60);
        tableRekap.setEditable(false);


        //main Layout

        navigasikiri = new StackPane();
        navigasikiri.getChildren().addAll(navigasi, logo, navGridPane, logout);

        contentkanan = new StackPane();
        contentkanan.getChildren().addAll(dashBoardtxt, garisdashBoardtxt, username123, lingkaranActive, arayaLand, boardAraya, circle, detailAraya,

                tableTotalPropertiYangDijual, cardDownlaod, downloadExcel, excel1, texttotalDIJUAL, totalPropertiDIJUAL,
                tableTotalPropertiBelumTerjual, hapus, texttotalBELUMTERJUAL, totalPropertiBELUMTERJUAL,
                tableTotalPropertiSudahTerjual, texttotalSUDAHTERJUAL, totalPropertiSUDAHTERJUAL,
                tableAllFasilitas, texttotalFASILITAS, totalFASILITAS,
                tableAllKomunitas, texttotalKOMUNITAS, totalKOMUNITAS,
                tableAllLayananKebersihan, texttotalCS, totalCS,
                RekapText, tableRekap

        );

        all = new HBox(navigasikiri, contentkanan);

        scrollPane = new ScrollPane();
        scrollPane.setContent(all);
        scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);

        Scene scene = new Scene(scrollPane);

        stage.setTitle("Admin Dashboard");
        stage.setMaximized(true);
        stage.setScene(scene);
        stage.show();

        iconDashboard.setOnMouseClicked(mouseEvent -> {
            AdminDashboard adminDashboard = new AdminDashboard();
            showSucces("Already in there", "Anda sudah berada dihalaman Dashboard");
            adminDashboard.setUsername(username);
        });

        iconManajemenPr.setOnMouseClicked(mouseEvent -> {
            AdminProperty adminProperty = new AdminProperty();
            try {
                Stage newStage = new Stage();
                adminProperty.setUsername(username);
                adminProperty.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        hapus.setOnAction(event -> {
            // Mendapatkan baris yang dipilih
            TotalPropertiBelumTerjual selectedProperti = tableTotalPropertiBelumTerjual.getSelectionModel().getSelectedItem();

            if (selectedProperti != null) {
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    // Query untuk menghapus dari database
                    String deleteSQL = "DELETE FROM ARAYALANDBASDAT.PROPERTI WHERE NO_PR = ?";
                    PreparedStatement pstmt = conn.prepareStatement(deleteSQL);
                    pstmt.setString(1, selectedProperti.getNomor_Properti());

                    // Melakukan penghapusan dari database
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        showSucces("Delete Data", "Data Berhasil Dihapus");

                        // Jika berhasil dihapus dari database, hapus juga dari tabel
                        tableTotalPropertiBelumTerjual.getItems().remove(selectedProperti);

                        tableTotalPropertiYangDijual.getItems().clear();
                        getTable1();

                        tableTotalPropertiBelumTerjual.getItems().clear();
                        getTable2();

                        tableTotalPropertiSudahTerjual.getItems().clear();
                        getTable3();

                        tableRekap.getItems().clear();
                        getRekap();
                    } else {
                        showAlert("Error Delete", "Data Tidak Berhasil Dihapus");
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Choose Line", "Pilih baris terlebih dahulu");
            }
        });

        excel1.setOnMouseClicked(mouseEvent -> {
            // Mengatur nama file CSV yang akan dibuat
            String csvFilePath = generateUniqueFileName("LAPORAN_REALESTATE.csv");

            try (PrintWriter writer = new PrintWriter(new File(csvFilePath))) {

                writer.println("LAPORAN ARAYALAND " + LocalDate.now());

                writer.println("Total Properti Yang Dijual");

                StringBuilder headerAllTotalPropertiYangDijual = new StringBuilder();
                headerAllTotalPropertiYangDijual.append("NOMOR PROPERTI,");
                headerAllTotalPropertiYangDijual.append("NAMA PROPERTI,");
                headerAllTotalPropertiYangDijual.append("AREA PROPERTI,");
                headerAllTotalPropertiYangDijual.append("LUAS TANAH,");
                headerAllTotalPropertiYangDijual.append("HARGA TANAH,");
                headerAllTotalPropertiYangDijual.append("LUAS BANGUNAN,");
                headerAllTotalPropertiYangDijual.append("HARGA BANGUNAN,");
                headerAllTotalPropertiYangDijual.append("PPN 10%,");
                headerAllTotalPropertiYangDijual.append("HARGA TOTAL,");
                writer.println(headerAllTotalPropertiYangDijual);

                ObservableList<TotalPropertiYangDijual> itemTotalPropertiYangDijual = tableTotalPropertiYangDijual.getItems();
                for (TotalPropertiYangDijual item : itemTotalPropertiYangDijual) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomorProperti()).append(",");
                    dataLine.append(item.getNamaProperti()).append(",");
                    dataLine.append(item.getAreaProperti()).append(",");
                    dataLine.append(item.getLuasTanahProperti()).append(",");
                    dataLine.append(item.getHargaTanahProperti()).append(",");
                    dataLine.append(item.getLuasBangunanProperti()).append(",");
                    dataLine.append(item.getHargaBangunanProperti()).append(",");
                    dataLine.append(item.getPpnProperti()).append(",");
                    dataLine.append(item.getHargaTotalProperti()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Properti Yang Belum Terjual");


                StringBuilder headerPropertiBelumTerjual = new StringBuilder();
                headerPropertiBelumTerjual.append("NOMOR PROPERTI,");
                headerPropertiBelumTerjual.append("NAMA PROPERTI,");
                headerPropertiBelumTerjual.append("AREA PROPERTI,");
                headerPropertiBelumTerjual.append("LUAS TANAH,");
                headerPropertiBelumTerjual.append("LUAS BANGUNAN,");
                writer.println(headerPropertiBelumTerjual);

                ObservableList<TotalPropertiBelumTerjual> itemTotalPropertiBelumTerjual = tableTotalPropertiBelumTerjual.getItems();
                for (TotalPropertiBelumTerjual item : itemTotalPropertiBelumTerjual) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getNama_Properti()).append(",");
                    dataLine.append(item.getArea_Properti()).append(",");
                    dataLine.append(item.getLuas_Tanah_Properti()).append(",");
                    dataLine.append(item.getLuas_Bangunan_Properti()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Properti Yang Sudah Terjual");


                StringBuilder headerPropertiSudahTerjual = new StringBuilder();
                headerPropertiSudahTerjual.append("USERNAME,");
                headerPropertiSudahTerjual.append("ID TRANSAKSI,");
                headerPropertiSudahTerjual.append("NOMOR PROPERTI,");
                headerPropertiSudahTerjual.append("NAMA PROPERTI,");
                headerPropertiSudahTerjual.append("AREA PROPERTI,");
                headerPropertiSudahTerjual.append("LUAS TANAH,");
                headerPropertiSudahTerjual.append("LUAS BANGUNAN,");
                headerPropertiSudahTerjual.append("STATUS PROPERTI,");

                writer.println(headerPropertiSudahTerjual);

                ObservableList<TotalPropertiSudahTerjual> itemTotalPropertiSudahTerjual = tableTotalPropertiSudahTerjual.getItems();
                for (TotalPropertiSudahTerjual item : itemTotalPropertiSudahTerjual) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getUsername_Properti()).append(",");
                    dataLine.append(item.getID_Transaksi()).append(",");
                    dataLine.append(item.getNomor_Properti()).append(",");
                    dataLine.append(item.getNama_Properti()).append(",");
                    dataLine.append(item.getArea_Properti()).append(",");
                    dataLine.append(item.getLuas_Tanah_Properti()).append(",");
                    dataLine.append(item.getLuas_Bangunan_Properti()).append(",");
                    dataLine.append(item.getStatus_Properti()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Fasilitas");

                StringBuilder headerAllFasilitas = new StringBuilder();
                headerAllFasilitas.append("NAMA FASILITAS,");
                headerAllFasilitas.append("HARI OPERASIONAL,");
                headerAllFasilitas.append("JAM OPERASIONAL,");
                headerAllFasilitas.append("KAPASITAS,");
                headerAllFasilitas.append("RATING,");

                writer.println(headerAllFasilitas);

                ObservableList<AllFasilitas> itemAllFasilitas = tableAllFasilitas.getItems();
                for (AllFasilitas item : itemAllFasilitas) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNama_Fasilitas()).append(",");
                    dataLine.append(item.getHari_Operasional()).append(",");
                    dataLine.append(item.getJam_Operasional()).append(",");
                    dataLine.append(item.getKapasitas()).append(",");
                    dataLine.append(item.getRating()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Komunitas");

                StringBuilder headerAllKomunitas = new StringBuilder();
                headerAllKomunitas.append("NAMA KOMUNITAS,");
                headerAllKomunitas.append("TANGGAL PENDIRIAN,");
                headerAllKomunitas.append("AGENDA,");
                headerAllKomunitas.append("SYARAT,");

                writer.println(headerAllKomunitas);

                ObservableList<AllKomunitas> itemAllKomunitas = tableAllKomunitas.getItems();
                for (AllKomunitas item : itemAllKomunitas) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getNama_Komunitas()).append(",");
                    dataLine.append(item.getTanggal_Pendirian()).append(",");
                    dataLine.append(item.getAgenda_Komunitas()).append(",");
                    dataLine.append(item.getSyarat_Komunitas()).append(",");
                    writer.println(dataLine);
                }

                writer.println();
                writer.println("Total Layanan Kebersihan");


                // Menulis header untuk tableAllLayananKebersihan ke file CSV
                StringBuilder headerAllLayanan = new StringBuilder();
                headerAllLayanan.append("ID PENGANGKUTAN,");
                headerAllLayanan.append("HARI OPERASIONAL,");
                headerAllLayanan.append("JAM OPERASIONAL,");
                headerAllLayanan.append("JENIS TRUK");
                writer.println(headerAllLayanan);

                // Menulis data dari tableAllLayananKebersihan ke file CSV
                ObservableList<AllLayananKebersihan> itemsAllLayanan = tableAllLayananKebersihan.getItems();
                for (AllLayananKebersihan item : itemsAllLayanan) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getId_Pengangkutan()).append(",");
                    dataLine.append(item.getHari_Operasional()).append(",");
                    dataLine.append(item.getJam_Operasional()).append(",");
                    dataLine.append(item.getJenis_Truk());
                    writer.println(dataLine);
                }

                // Menambahkan baris kosong sebagai pemisah antara tabel
                writer.println();
                writer.println("Rekap ArayaLand");

                // Menulis header untuk tableRekap ke file CSV
                StringBuilder headerRekap = new StringBuilder();
                headerRekap.append("PROPERTI DIJUAL,");
                headerRekap.append("PROPERTI BELUM TERJUAL,");
                headerRekap.append("PROPERTI TERJUAL,");
                headerRekap.append("TOTAL FASILITAS,");
                headerRekap.append("TOTAL KOMUNITAS,");
                headerRekap.append("TOTAL KEBERSIHAN");
                writer.println(headerRekap);

                // Menulis data dari tableRekap ke file CSV
                ObservableList<rekap> itemsRekap = tableRekap.getItems();
                for (rekap item : itemsRekap) {
                    StringBuilder dataLine = new StringBuilder();
                    dataLine.append(item.getAllPropertiDijual()).append(",");
                    dataLine.append(item.getAllPropertiBelumDijual()).append(",");
                    dataLine.append(item.getAllPropertiSudahDijual()).append(",");
                    dataLine.append(item.getAllFasilitasTersedia()).append(",");
                    dataLine.append(item.getAllKomunitasTersedia()).append(",");
                    dataLine.append(item.getAllCSTersedia());
                    writer.println(dataLine);
                }

                showSucces("CSV FILE", "Berhasil Mendownload " + csvFilePath);
                Runtime.getRuntime().exec("cmd /c start " + csvFilePath);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });


        iconManajemenFs.setOnMouseClicked(mouseEvent -> {
            AdminFacility adminFacility = new AdminFacility();
            try {
                Stage newStage = new Stage();
                adminFacility.setUsername(username);
                adminFacility.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        iconManajemenKm.setOnMouseClicked(mouseEvent -> {
            AdminCommunity adminCommunity = new AdminCommunity();
            try {
                Stage newStage = new Stage();
                adminCommunity.setUsername(username);
                adminCommunity.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        iconManajemenKb.setOnMouseClicked(mouseEvent -> {
            AdminCS adminCS = new AdminCS();
            try {
                Stage newStage = new Stage();
                adminCS.setUsername(username);
                adminCS.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        logout.setOnMouseClicked(mouseEvent -> {
            MainLogin mainLogin = new MainLogin();
            try {
                Stage newStage = new Stage();
                mainLogin.start(newStage);
                newStage.setResizable(true);
                stage.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        });


        ig.setOnMouseClicked(mouseEvent -> {
            String url_ig = "https://www.instagram.com/araya_familyclub/";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(url_ig);
            clipboard.setContent(content);
            showSucces("URL IG", "URL Instagram ArayaLand berhasil dicopy");
        });

        namaig.setOnAction(event -> {
            String url_ig = "https://www.instagram.com/araya_familyclub/";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(url_ig);
            clipboard.setContent(content);
            showSucces("URL IG", "URL Instagram ArayaLand berhasil dicopy");
        });

        lok.setOnMouseClicked(mouseEvent -> {
            String lok_url = "https://maps.app.goo.gl/pjkswYTfrVjUwv8r9";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(lok_url);
            clipboard.setContent(content);
            showSucces("URL GMAPS", "URL GMaps ArayaLand berhasil dicopy");
        });

        alamatlokasi.setOnAction(event -> {
            String lok_url = "https://maps.app.goo.gl/pjkswYTfrVjUwv8r9";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(lok_url);
            clipboard.setContent(content);
            showSucces("URL GMAPS", "URL GMaps ArayaLand berhasil dicopy");
        });

        no.setOnMouseClicked(mouseEvent -> {
            String phoneNumber = "08510013143";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(phoneNumber);
            clipboard.setContent(content);
            showSucces("Nomor Telepon", "Nomor kontak ArayaLand berhasil dicopy");
        });

        nomoraraya.setOnAction(event -> {
            String phoneNumber = "08510013143";
            Clipboard clipboard = Clipboard.getSystemClipboard();
            ClipboardContent content = new ClipboardContent();
            content.putString(phoneNumber);
            clipboard.setContent(content);
            showSucces("Nomor Telepon", "Nomor kontak ArayaLand berhasil dicopy");
        });

        //SQLTABLE

        getTable1();
        getTable2();
        getTable3();
        getTable4();
        getTable5();
        getTable6();
        getRekap();
    }

    private void showNextImage() {
        current_image = (current_image + 1) % IMAGE_ARAYA.length;
        boardAraya.setImage(new Image(getClass().getResourceAsStream(IMAGE_ARAYA[current_image])));
    }

    private void showSucces(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void getTable1() {
        String selectSQL = "SELECT NO_PR, NAMA_PR, AREA_PR, LUASTANAH, HARGATANAH, LUASBG, HARGABANGUNAN, PPN, HARGA_TOTAL" +
                " FROM ARAYALANDBASDAT.PROPERTI";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<TotalPropertiYangDijual> totalPropertiYangDijuals = new ArrayList<>();
            while (resultSet.next()) {
                TotalPropertiYangDijual totalPropertiYangDijual = new TotalPropertiYangDijual();
                totalPropertiYangDijual.setNomorProperti(resultSet.getString("NO_PR"));
                totalPropertiYangDijual.setNamaProperti(resultSet.getString("NAMA_PR"));
                totalPropertiYangDijual.setAreaProperti(resultSet.getString("AREA_PR"));
                totalPropertiYangDijual.setLuasTanahProperti(resultSet.getDouble("LUASTANAH"));
                totalPropertiYangDijual.setHargaTanahProperti(resultSet.getDouble("HARGATANAH"));
                totalPropertiYangDijual.setLuasBangunanProperti(resultSet.getDouble("LUASBG"));
                totalPropertiYangDijual.setHargaBangunanProperti(resultSet.getDouble("HARGABANGUNAN"));
                totalPropertiYangDijual.setPpnProperti(resultSet.getDouble("PPN"));
                totalPropertiYangDijual.setHargaTotalProperti(resultSet.getDouble("HARGA_TOTAL"));
                totalPropertiYangDijuals.add(totalPropertiYangDijual);
            }

            tableTotalPropertiYangDijual.getItems().addAll(totalPropertiYangDijuals);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void getTable2() {
        String selectSQL = "SELECT NO_PR, NAMA_PR, AREA_PR, LUASTANAH, LUASBG " +
                "FROM ARAYALANDBASDAT.PROPERTI " +
                "WHERE NO_PR NOT IN ( " +
                "    SELECT PROPERTI_NO_PR " +
                "    FROM ARAYALANDBASDAT.INFOPROPERTI " +
                ")";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<TotalPropertiBelumTerjual> totalPropertiBelumTerjuals = new ArrayList<>();
            while (resultSet.next()) {
                TotalPropertiBelumTerjual totalPropertiBelumTerjual = new TotalPropertiBelumTerjual();
                totalPropertiBelumTerjual.setNomor_Properti(resultSet.getString("NO_PR"));
                totalPropertiBelumTerjual.setNama_Properti(resultSet.getString("NAMA_PR"));
                totalPropertiBelumTerjual.setArea_Properti(resultSet.getString("AREA_PR"));
                totalPropertiBelumTerjual.setLuas_Tanah_Properti(resultSet.getDouble("LUASTANAH"));
                totalPropertiBelumTerjual.setLuas_Bangunan_Properti(resultSet.getDouble("LUASBG"));
                totalPropertiBelumTerjuals.add(totalPropertiBelumTerjual);
            }

            tableTotalPropertiBelumTerjual.getItems().addAll(totalPropertiBelumTerjuals);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable3() {
        String selectSQL = "SELECT A.NAMA_AC, PR.TRANSAKSI_ID_TR, PR.PROPERTI_NO_PR, P.NAMA_PR, P.AREA_PR, P.LUASTANAH, P.LUASBG, PR.STATUS_PR\n" +
                "FROM ARAYALANDBASDAT.INFOPROPERTI PR\n" +
                "INNER JOIN ARAYALANDBASDAT.PROPERTI P ON PR.PROPERTI_NO_PR = P.NO_PR\n" +
                "INNER JOIN ARAYALANDBASDAT.ACCOUNT A ON PR.ACCOUNT_USNM_AC = A.USNM_AC";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<TotalPropertiSudahTerjual> totalPropertiSudahTerjuals = new ArrayList<>();
            while (resultSet.next()) {
                TotalPropertiSudahTerjual totalPropertiSudahTerjual = new TotalPropertiSudahTerjual();
                totalPropertiSudahTerjual.setUsername_Properti(resultSet.getString("NAMA_AC"));
                totalPropertiSudahTerjual.setID_Transaksi(resultSet.getString("TRANSAKSI_ID_TR"));
                totalPropertiSudahTerjual.setNomor_Properti(resultSet.getString("PROPERTI_NO_PR"));
                totalPropertiSudahTerjual.setNama_Properti(resultSet.getString("NAMA_PR"));
                totalPropertiSudahTerjual.setArea_Properti(resultSet.getString("AREA_PR"));
                totalPropertiSudahTerjual.setLuas_Tanah_Properti(resultSet.getDouble("LUASTANAH"));
                totalPropertiSudahTerjual.setLuas_Bangunan_Properti(resultSet.getDouble("LUASBG"));
                totalPropertiSudahTerjual.setStatus_Properti(resultSet.getString("STATUS_PR"));
                totalPropertiSudahTerjuals.add(totalPropertiSudahTerjual);
            }

            tableTotalPropertiSudahTerjual.getItems().addAll(totalPropertiSudahTerjuals);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable4() {
        String selectSQL = "SELECT NAMA_FU, HARI_FU, JAM_FU, KAPASITAS_FU, RATING_FU" +
                " FROM ARAYALANDBASDAT.FASILITAS";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<AllFasilitas> totalFasilitas = new ArrayList<>();
            while (resultSet.next()) {
                AllFasilitas allFasilitas = new AllFasilitas();
                allFasilitas.setNama_Fasilitas(resultSet.getString("NAMA_FU"));
                allFasilitas.setHari_Operasional(resultSet.getString("HARI_FU"));
                allFasilitas.setJam_Operasional(resultSet.getString("JAM_FU"));
                allFasilitas.setKapasitas(resultSet.getDouble("KAPASITAS_FU"));
                allFasilitas.setRating(resultSet.getDouble("RATING_FU"));
                totalFasilitas.add(allFasilitas);
            }

            tableAllFasilitas.getItems().addAll(totalFasilitas);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable5() {
        String selectSQL = "SELECT NAMA_KM, TGL_PDRN,AGENDA_KM, SYARAT_KM" +
                " FROM ARAYALANDBASDAT.KOMUNITAS";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<AllKomunitas> totalKomunitas = new ArrayList<>();
            while (resultSet.next()) {
                AllKomunitas allKomunitas = new AllKomunitas();
                allKomunitas.setNama_Komunitas(resultSet.getString("NAMA_KM"));
                allKomunitas.setTanggal_Pendirian(resultSet.getString("TGL_PDRN"));
                allKomunitas.setAgenda_Komunitas(resultSet.getString("AGENDA_KM"));
                allKomunitas.setSyarat_Komunitas(resultSet.getString("SYARAT_KM"));

                totalKomunitas.add(allKomunitas);
            }

            tableAllKomunitas.getItems().addAll(totalKomunitas);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void getTable6() {
        String selectSQL = "SELECT ID_KB, HARI_KB, JAM_KB, JENIS_TRUK" +
                " FROM ARAYALANDBASDAT.KEBERSIHAN";
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(selectSQL)) {

            ResultSet resultSet = pstmt.executeQuery();
            List<AllLayananKebersihan> totalKebersihan = new ArrayList<>();
            while (resultSet.next()) {
                AllLayananKebersihan allLayananKebersihan = new AllLayananKebersihan();
                allLayananKebersihan.setId_Pengangkutan(resultSet.getString("ID_KB"));
                allLayananKebersihan.setHari_Operasional(resultSet.getString("HARI_KB"));
                allLayananKebersihan.setJam_Operasional(resultSet.getString("JAM_KB"));
                allLayananKebersihan.setJenis_Truk(resultSet.getString("JENIS_TRUK"));

                totalKebersihan.add(allLayananKebersihan);
            }

            tableAllLayananKebersihan.getItems().addAll(totalKebersihan);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void getRekap() {
        String countPropertiDijualSQL = "SELECT COUNT(*) AS TOTAL_PROPERTI_DIJUAL FROM ARAYALANDBASDAT.PROPERTI";

        String countPropertiBelumSQL = "SELECT COUNT(*) AS TOTAL_PROPERTI_BELUM_TERJUAL FROM ARAYALANDBASDAT.PROPERTI " +
                "WHERE NO_PR NOT IN (SELECT PROPERTI_NO_PR FROM ARAYALANDBASDAT.INFOPROPERTI)";

        String countPropertiTerjualSQL = "SELECT COUNT(*) AS TOTAL_PROPERTI_TERJUAL FROM ARAYALANDBASDAT.INFOPROPERTI";

        String countFasilitasSQL = "SELECT COUNT(*) AS TOTAL_FASILITAS FROM ARAYALANDBASDAT.FASILITAS";

        String countKomunitasSQL = "SELECT COUNT(*) AS TOTAL_KOMUNITAS FROM ARAYALANDBASDAT.KOMUNITAS";

        String countKebersihanSQL = "SELECT COUNT(*) AS TOTAL_KEBERSIHAN FROM ARAYALANDBASDAT.KEBERSIHAN";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            PreparedStatement pstmtPropertiDijual = conn.prepareStatement(countPropertiDijualSQL);
            PreparedStatement pstmtPropertiBelum = conn.prepareStatement(countPropertiBelumSQL);
            PreparedStatement pstmtPropertiTerjual = conn.prepareStatement(countPropertiTerjualSQL);
            PreparedStatement pstmtFasilitas = conn.prepareStatement(countFasilitasSQL);
            PreparedStatement pstmtKomunitas = conn.prepareStatement(countKomunitasSQL);
            PreparedStatement pstmtKebersihan = conn.prepareStatement(countKebersihanSQL);

            ResultSet resultSetPropertiDijual = pstmtPropertiDijual.executeQuery();
            ResultSet resultSetPropertiBelum = pstmtPropertiBelum.executeQuery();
            ResultSet resultSetPropertiTerjual = pstmtPropertiTerjual.executeQuery();
            ResultSet resultSetFasilitas = pstmtFasilitas.executeQuery();
            ResultSet resultSetKomunitas = pstmtKomunitas.executeQuery();
            ResultSet resultSetKebersihan = pstmtKebersihan.executeQuery();

            rekap rekap = new rekap();

            if (resultSetPropertiDijual.next()) {
                rekap.setAllPropertiDijual(resultSetPropertiDijual.getString("TOTAL_PROPERTI_DIJUAL"));
            }
            if (resultSetPropertiBelum.next()) {
                rekap.setAllPropertiBelumDijual(resultSetPropertiBelum.getString("TOTAL_PROPERTI_BELUM_TERJUAL"));
            }
            if (resultSetPropertiTerjual.next()) {
                rekap.setAllPropertiSudahDijual(resultSetPropertiTerjual.getString("TOTAL_PROPERTI_TERJUAL"));
            }
            if (resultSetFasilitas.next()) {
                rekap.setAllFasilitasTersedia(resultSetFasilitas.getString("TOTAL_FASILITAS"));
            }
            if (resultSetKomunitas.next()) {
                rekap.setAllKomunitasTersedia(resultSetKomunitas.getString("TOTAL_KOMUNITAS"));
            }
            if (resultSetKebersihan.next()) {
                rekap.setAllCSTersedia(resultSetKebersihan.getString("TOTAL_KEBERSIHAN"));
            }

            tableRekap.getItems().add(rekap);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static String generateUniqueFileName(String baseFileName) {
        String fileName = baseFileName;
        File file = new File(fileName);
        while (file.exists()) {
            fileCounter++;
            int extensionIndex = baseFileName.lastIndexOf('.');
            if (extensionIndex == -1) {
                fileName = baseFileName + "(" + fileCounter + ")";
            } else {
                fileName = baseFileName.substring(0, extensionIndex) + "(" + fileCounter + ")" +
                        baseFileName.substring(extensionIndex);
            }
            file = new File(fileName);
        }
        return fileName;
    }
}


