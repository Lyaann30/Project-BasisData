package com.example.arayalandbasdat;

public class FakeMain {
    public static void main(String[] args) {
        MainLogin.main(args);
    }
}
