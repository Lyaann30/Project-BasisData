module com.example.arayalandbasdat {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens com.example.arayalandbasdat to javafx.base;
    exports com.example.arayalandbasdat;
}
